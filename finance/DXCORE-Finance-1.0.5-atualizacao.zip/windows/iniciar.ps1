﻿# DXCORE Finance - servidor (roda escondido enquanto o Windows estiver ligado)
# Liga o banco, mantém o sistema no ar (religa se cair) e faz o backup diário.
. (Join-Path $PSScriptRoot 'comum.ps1')
. (Join-Path $PSScriptRoot 'atualizacao.ps1')
$criado = $false
$mutex = New-Object Threading.Mutex($true, 'Local\DXCORE-Finance-Servidor', [ref]$criado)
if (-not $criado) { exit 0 }  # já está rodando
try {
  $c = LerConfig
  LigarBanco $c
  $ip = IpLocal
  $env:PORT = [string]$c.porta
  $env:HOSTNAME = '0.0.0.0'
  $env:NODE_ENV = 'production'
  $env:TZ = 'UTC'
  $env:APP_URL = "http://${ip}:$($c.porta)"
  $env:DATABASE_URL = "postgres://dxcore_app_login:$(Decifrar $c.senhaApp)@127.0.0.1:$($c.portaBanco)/dxcore_finance"
  if ($c.smtpUrl) { $env:SMTP_URL = Decifrar $c.smtpUrl; $env:EMAIL_REMETENTE = $c.emailRemetente }
  Log "servidor iniciando em $($env:APP_URL) (banco ligado)"
  $ultimoBackup = $null
  $proximaBusca = (Get-Date).AddMinutes(2)   # procura atualização 2 min depois de ligar e a cada 6 h
  $quedas = 0; $religar = $false
  while ($true) {
    $inicio = Get-Date
    $p = Start-Process -FilePath $DXNode -ArgumentList ('"' + (Join-Path $DXSistema 'server.js') + '"') -WorkingDirectory $DXSistema `
      -NoNewWindow -PassThru -RedirectStandardOutput (Join-Path $DXLog 'sistema.log') -RedirectStandardError (Join-Path $DXLog 'sistema-erros.log')
    while (-not $p.HasExited) {
      Start-Sleep -Seconds 60
      # backup uma vez por dia (o primeiro após ligar e depois a cada 24 h)
      $hoje = Get-Date -Format 'yyyy-MM-dd'
      if ($ultimoBackup -ne $hoje) {
        $existe = Test-Path (Join-Path $DXBackups "dxcore-finance-$hoje*-diario.dxbak")
        if (-not $existe) { try { FazerBackup $c 'diario' | Out-Null } catch { Log ('backup diário falhou: ' + $_.Exception.Message) } }
        $ultimoBackup = $hoje
      }
      if (-not (BancoLigado $c)) { try { LigarBanco $c } catch { Log $_.Exception.Message } }
      if ((Get-Date) -ge $proximaBusca) {
        $proximaBusca = (Get-Date).AddHours(6)
        $m = ProcurarAtualizacao
        if ($m) {
          Log "versão nova encontrada: $($m.versao)"
          Stop-Process -Id $p.Id -Force -ErrorAction SilentlyContinue; Start-Sleep -Seconds 2
          try { AplicarAtualizacao $c $m; $religar = $true; break } catch { Log ('atualização falhou: ' + $_.Exception.Message + ' (continua na versão atual)') }
        }
      }
    }
    if ($religar) { break }
    # versão nova que não para de cair logo depois de atualizar: volta para a anterior
    if (((Get-Date) - $inicio).TotalSeconds -lt 60) { $quedas++ } else { $quedas = 0 }
    if ($quedas -ge 3 -and (Test-Path $DXMarcaAtual)) {
      try { VoltarVersaoAnterior; $religar = $true; break } catch { Log $_.Exception.Message }
    }
    Log "sistema parou (código $($p.ExitCode)); religando em 5 s"
    Start-Sleep -Seconds 5
  }
  if ($religar) {
    # recomeça o servidor com os scripts novos
    $mutex.ReleaseMutex(); $mutex = $null
    Start-Process -FilePath (Join-Path $env:WINDIR 'System32\wscript.exe') -ArgumentList ('"' + (Join-Path $PSScriptRoot 'iniciar.vbs') + '"')
  }
} catch {
  Log ('ERRO servidor: ' + $_.Exception.Message)
} finally {
  if ($mutex) { try { $mutex.ReleaseMutex() } catch {} }
}
