﻿# DXCORE Finance - restaurar um backup (substitui TODOS os dados atuais)
. (Join-Path $PSScriptRoot 'comum.ps1')
Add-Type -AssemblyName System.Windows.Forms
$Host.UI.RawUI.WindowTitle = 'DXCORE Finance - restaurar backup'
if (-not (Test-Path $DXCfgArq)) { Write-Host 'O DXCORE Finance não está instalado neste computador.' -ForegroundColor Red; exit 1 }
$dlg = New-Object System.Windows.Forms.OpenFileDialog
$dlg.Title = 'Escolha o backup do DXCORE Finance'
$dlg.Filter = 'Backup DXCORE Finance (*.dxbak)|*.dxbak'
$dlg.InitialDirectory = $DXBackups
if ($dlg.ShowDialog() -ne 'OK') { Write-Host 'Cancelado.'; exit 0 }
Write-Host "Backup escolhido: $($dlg.FileName)"
Write-Host 'ATENÇÃO: todos os dados atuais serão substituídos pelos do backup.' -ForegroundColor Yellow
if ((Read-Host 'Digite RESTAURAR para confirmar') -ne 'RESTAURAR') { Write-Host 'Cancelado.'; exit 0 }
try {
  $c = LerConfig
  LigarBanco $c
  Write-Host '-> Guardando um backup do estado atual (por segurança)'
  $seg = FazerBackup $c 'antes-restaurar'
  Write-Host "   $seg" -ForegroundColor Green
  PararSistema
  Start-Sleep -Seconds 2
  $u = UrlsAdmin $c
  Write-Host '-> Recriando o banco'
  $js = "const p=require('postgres');(async()=>{const s=p(process.env.U,{max:1});await s.unsafe('DROP DATABASE IF EXISTS dxcore_finance WITH (FORCE)');await s.end()})().catch(e=>{console.error(e.message);process.exit(1)})"
  $env:U = $u.Postgres
  Push-Location $DXSistema; & $DXNode -e $js; $cod = $LASTEXITCODE; Pop-Location
  if ($cod -ne 0) { throw 'Não foi possível recriar o banco.' }
  $cod = RodarNode 'scripts\preparar-banco.mjs' @{ PG_ADMIN_URL = $u.Postgres; SENHA_APP = (Decifrar $c.senhaApp) }
  if ($cod -ne 0) { throw 'Não foi possível preparar o banco.' }
  Write-Host '-> Restaurando os dados'
  $cod = RodarNode 'scripts\restaurar-dados.mjs' @{ DATABASE_URL_ADMIN = $u.Banco } @($dlg.FileName)
  if ($cod -ne 0) { throw "A restauração falhou. O estado anterior está em $seg" }
  Start-Process -FilePath (Join-Path $env:WINDIR 'System32\wscript.exe') -ArgumentList ('"' + (Join-Path $DXProg 'windows\abrir.vbs') + '"')
  Write-Host ''; Write-Host 'Backup restaurado.' -ForegroundColor Green
} catch {
  Write-Host ''; Write-Host ('ERRO: ' + $_.Exception.Message) -ForegroundColor Red
  Log ('restaurar: ' + $_.Exception.Message)
  exit 1
}
