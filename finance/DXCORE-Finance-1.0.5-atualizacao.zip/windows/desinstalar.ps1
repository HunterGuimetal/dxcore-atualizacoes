﻿# DXCORE Finance - desinstalar (os backups em Documentos são mantidos)
. (Join-Path $PSScriptRoot 'comum.ps1')
Write-Host 'Isto remove o DXCORE Finance e TODOS os dados deste computador.' -ForegroundColor Yellow
Write-Host "Os backups em $DXBackups NÃO são apagados."
if ((Read-Host 'Digite DESINSTALAR para confirmar') -ne 'DESINSTALAR') { Write-Host 'Cancelado.'; exit 0 }
if (Test-Path $DXCfgArq) { try { $c = LerConfig; LigarBanco $c; FazerBackup $c 'antes-desinstalar' | Out-Null } catch {} }
try { LimparInstalacao } catch { Write-Host $_.Exception.Message -ForegroundColor Red; exit 1 }
Write-Host 'DXCORE Finance removido.' -ForegroundColor Green
