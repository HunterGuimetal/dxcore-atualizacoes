﻿# DXCORE Finance - abre o sistema (liga o servidor se ainda não estiver no ar)
. (Join-Path $PSScriptRoot 'comum.ps1')
Add-Type -AssemblyName System.Windows.Forms
try {
  $c = LerConfig
  if (-not (SistemaResponde $c)) {
    Start-Process -FilePath (Join-Path $env:WINDIR 'System32\wscript.exe') -ArgumentList ('"' + (Join-Path $PSScriptRoot 'iniciar.vbs') + '"')
    $ok = $false
    for ($i = 0; $i -lt 60; $i++) { Start-Sleep -Milliseconds 750; if (SistemaResponde $c) { $ok = $true; break } }
    if (-not $ok) { throw "O DXCORE Finance não respondeu. Veja os registros em $DXLog" }
  }
  $url = "http://localhost:$($c.porta)/"
  $nav = Navegador
  if ($nav) { Start-Process -FilePath $nav -ArgumentList "--app=$url" } else { Start-Process $url }
} catch {
  Log ('abrir: ' + $_.Exception.Message)
  [System.Windows.Forms.MessageBox]::Show($_.Exception.Message, 'DXCORE Finance', 'OK', 'Error') | Out-Null
}
