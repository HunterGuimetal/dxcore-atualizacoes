﻿# DXCORE Finance - atualização automática (igual ao DXCORE Industrial)
# Confere a versão publicada, a ASSINATURA DIGITAL (chave pública deste computador) e o SHA-256 do pacote,
# faz backup, troca o sistema, atualiza o banco e guarda a versão anterior para voltar se algo falhar.
$Global:DXAtualUrl = 'https://dxcore.guimetal.com.br/finance'
$Global:DXAnterior = Join-Path $DX 'programa-anterior'
$Global:DXMarcaAtual = Join-Path $DX 'atualizado.json'

function VersaoInstalada { return (Get-Content (Join-Path $DXProg 'versao.txt') -Raw).Trim() }

function Baixar([string]$url, [string]$destino) {
  $ProgressPreference = 'SilentlyContinue'
  [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
  Invoke-WebRequest -UseBasicParsing -TimeoutSec 120 -Uri ($url + '?t=' + [DateTime]::UtcNow.Ticks) -OutFile $destino
}

# Devolve o manifesto da versão nova (já com a assinatura conferida) ou $null.
function ProcurarAtualizacao {
  $tmp = Join-Path $env:TEMP ('dxfin-' + [guid]::NewGuid())
  New-Item -ItemType Directory -Path $tmp -Force | Out-Null
  try {
    Baixar "$DXAtualUrl/versao.json" (Join-Path $tmp 'versao.json')
    Baixar "$DXAtualUrl/versao.json.sig" (Join-Path $tmp 'versao.json.sig')
    $bytes = [IO.File]::ReadAllBytes((Join-Path $tmp 'versao.json'))
    $sig = [Convert]::FromBase64String((Get-Content (Join-Path $tmp 'versao.json.sig') -Raw).Trim())
    $rsa = New-Object Security.Cryptography.RSACryptoServiceProvider
    $rsa.FromXmlString((Get-Content (Join-Path $DXProg 'windows\chave-publica.xml') -Raw))
    if (-not $rsa.VerifyData($bytes, 'SHA256', $sig)) { Log 'atualização: assinatura INVÁLIDA, ignorada'; return $null }
    $m = [Text.Encoding]::UTF8.GetString($bytes) | ConvertFrom-Json
    if ([version]$m.versao -le [version](VersaoInstalada)) { return $null }
    return $m
  } catch {
    Log ('atualização: não foi possível verificar (' + $_.Exception.Message + ')')
    return $null
  } finally { Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue }
}

# O sistema (Node) precisa estar PARADO. Lança erro se falhar (e já voltou ao que era).
function AplicarAtualizacao($c, $m) {
  $tmp = Join-Path $env:TEMP ('dxfin-' + [guid]::NewGuid())
  New-Item -ItemType Directory -Path $tmp -Force | Out-Null
  try {
    $zip = Join-Path $tmp 'pacote.zip'
    Baixar "$DXAtualUrl/$($m.arquivo)" $zip
    $hash = (Get-FileHash $zip -Algorithm SHA256).Hash.ToLower()
    if ($hash -ne ([string]$m.sha256).ToLower()) { throw 'o pacote baixado não confere (SHA-256)' }
    Expand-Archive -Path $zip -DestinationPath (Join-Path $tmp 'novo') -Force
    $novo = Join-Path $tmp 'novo'
    if (-not (Test-Path (Join-Path $novo 'sistema\server.js'))) { throw 'pacote incompleto' }
    $ver = (Get-Content (Join-Path $novo 'versao.txt') -Raw).Trim()
    if ($ver -ne $m.versao) { throw 'versão do pacote diferente da anunciada' }

    FazerBackup $c 'antes-atualizar' | Out-Null
    # guarda a versão atual para poder voltar
    if (Test-Path $DXAnterior) { Remove-Item $DXAnterior -Recurse -Force }
    New-Item -ItemType Directory -Path $DXAnterior -Force | Out-Null
    $de = VersaoInstalada
    Move-Item (Join-Path $DXProg 'sistema') (Join-Path $DXAnterior 'sistema')
    Copy-Item (Join-Path $DXProg 'windows') $DXAnterior -Recurse -Force
    Copy-Item (Join-Path $DXProg 'versao.txt') $DXAnterior -Force
    try {
      Move-Item (Join-Path $novo 'sistema') (Join-Path $DXProg 'sistema')
      Copy-Item (Join-Path $novo 'windows\*') (Join-Path $DXProg 'windows') -Recurse -Force
      Copy-Item (Join-Path $novo 'versao.txt') $DXProg -Force
      $u = UrlsAdmin $c
      $cod = RodarNode 'scripts\preparar-banco.mjs' @{ PG_ADMIN_URL = $u.Postgres; SENHA_APP = (Decifrar $c.senhaApp) }
      if ($cod -ne 0) { throw 'a atualização do banco falhou' }
    } catch {
      VoltarVersaoAnterior
      throw
    }
    $c.versao = $m.versao; SalvarConfig $c
    @{ de = $de; para = $m.versao; em = (Get-Date -Format s) } | ConvertTo-Json | Set-Content $DXMarcaAtual -Encoding UTF8
    Log "atualizado de $de para $($m.versao)"
  } finally { Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue }
}

function VoltarVersaoAnterior {
  if (-not (Test-Path (Join-Path $DXAnterior 'sistema\server.js'))) { throw 'não há versão anterior guardada' }
  if (Test-Path (Join-Path $DXProg 'sistema')) { Remove-Item (Join-Path $DXProg 'sistema') -Recurse -Force }
  Copy-Item (Join-Path $DXAnterior 'sistema') $DXProg -Recurse -Force
  Copy-Item (Join-Path $DXAnterior 'windows\*') (Join-Path $DXProg 'windows') -Recurse -Force
  Copy-Item (Join-Path $DXAnterior 'versao.txt') $DXProg -Force
  try { $c = LerConfig; $c.versao = VersaoInstalada; SalvarConfig $c } catch {}
  Remove-Item $DXMarcaAtual -Force -ErrorAction SilentlyContinue
  Log ('voltou para a versão anterior ' + (VersaoInstalada))
}
