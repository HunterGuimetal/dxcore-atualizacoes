﻿# DXCORE Finance - atualização (mantém os dados; faz backup antes)
$pacote = Split-Path -Parent $PSScriptRoot
. (Join-Path $PSScriptRoot 'comum.ps1')
$Host.UI.RawUI.WindowTitle = 'DXCORE Finance - atualização'
if (-not (Test-Path $DXCfgArq)) { Write-Host 'O DXCORE Finance não está instalado neste computador. Use o INSTALAR.bat.' -ForegroundColor Red; exit 1 }
try {
  $c = LerConfig
  $nova = (Get-Content (Join-Path $pacote 'versao.txt')).Trim()
  Write-Host "Atualizando da versão $($c.versao) para $nova..." -ForegroundColor Cyan
  Get-ChildItem -Path $pacote -Recurse -File | Unblock-File -ErrorAction SilentlyContinue
  Write-Host '-> Backup antes de atualizar'
  LigarBanco $c
  $b = FazerBackup $c 'antes-atualizar'
  Write-Host "   $b" -ForegroundColor Green
  Write-Host '-> Parando o sistema'
  PararSistema
  Start-Sleep -Seconds 2
  Write-Host '-> Copiando a versão nova'
  $anterior = Join-Path $DX 'programa-anterior'
  if (Test-Path $anterior) { Remove-Item $anterior -Recurse -Force }
  New-Item -ItemType Directory -Path $anterior -Force | Out-Null
  Copy-Item (Join-Path $DXProg 'sistema') $anterior -Recurse -Force
  Remove-Item (Join-Path $DXProg 'sistema') -Recurse -Force
  foreach ($d in @('sistema', 'windows')) { Copy-Item -Path (Join-Path $pacote $d) -Destination $DXProg -Recurse -Force }
  Copy-Item (Join-Path $pacote 'runtime\node.exe') (Join-Path $DXProg 'runtime\node.exe') -Force
  Copy-Item (Join-Path $pacote 'versao.txt') $DXProg -Force
  Write-Host '-> Atualizando o banco de dados'
  $u = UrlsAdmin $c
  $cod = RodarNode 'scripts\preparar-banco.mjs' @{ PG_ADMIN_URL = $u.Postgres; SENHA_APP = (Decifrar $c.senhaApp) }
  if ($cod -ne 0) { throw "A atualização do banco falhou. Os dados estão no backup $b" }
  $c.versao = $nova; SalvarConfig $c
  Write-Host '-> Ligando o sistema'
  Start-Process -FilePath (Join-Path $env:WINDIR 'System32\wscript.exe') -ArgumentList ('"' + (Join-Path $DXProg 'windows\abrir.vbs') + '"')
  Write-Host ''; Write-Host "Atualizado para a versão $nova." -ForegroundColor Green
  Log "atualizado para $nova"
} catch {
  Write-Host ''; Write-Host ('ERRO: ' + $_.Exception.Message) -ForegroundColor Red
  Log ('atualização: ' + $_.Exception.Message)
  exit 1
}
