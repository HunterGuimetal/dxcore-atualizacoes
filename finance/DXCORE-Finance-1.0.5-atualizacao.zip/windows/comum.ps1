﻿# DXCORE Finance - funções comuns dos scripts do Windows
$ErrorActionPreference = 'Stop'
$Global:DX = Join-Path $env:LOCALAPPDATA 'DXCORE-Finance'
$Global:DXProg = Join-Path $DX 'programa'
$Global:DXBanco = Join-Path $DX 'dados\banco'
$Global:DXLog = Join-Path $DX 'logs'
$Global:DXCfgArq = Join-Path $DX 'config.json'
$Global:DXBackups = Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'DXCORE-Finance-backups'
$Global:DXNode = Join-Path $DXProg 'runtime\node.exe'
$Global:DXPg = Join-Path $DXProg 'pgsql\bin'
$Global:DXSistema = Join-Path $DXProg 'sistema'

function Log([string]$m, [string]$arq = 'dxcore.log') {
  try {
    if (-not (Test-Path $DXLog)) { New-Item -ItemType Directory -Path $DXLog -Force | Out-Null }
    $f = Join-Path $DXLog $arq
    if ((Test-Path $f) -and ((Get-Item $f).Length -gt 1MB)) { Move-Item $f ($f + '.antigo') -Force }
    Add-Content -Path $f -Value ((Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + '  ' + $m) -Encoding UTF8
  } catch {}
}

# Senhas guardadas cifradas pelo Windows (DPAPI): só este usuário, neste computador, consegue ler.
function Cifrar([string]$texto) { return (ConvertTo-SecureString $texto -AsPlainText -Force | ConvertFrom-SecureString) }
function Decifrar([string]$cifrado) {
  $s = ConvertTo-SecureString $cifrado
  $p = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($s)
  try { return [Runtime.InteropServices.Marshal]::PtrToStringBSTR($p) } finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($p) }
}
function SenhaAleatoria([int]$n = 32) {
  $letras = [char[]]'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789'
  $bytes = New-Object byte[] $n
  [Security.Cryptography.RandomNumberGenerator]::Create().GetBytes($bytes)
  return -join ($bytes | ForEach-Object { $letras[$_ % $letras.Length] })
}

function LerConfig { return (Get-Content -LiteralPath $DXCfgArq -Raw -Encoding UTF8 | ConvertFrom-Json) }
function SalvarConfig($c) { ($c | ConvertTo-Json -Depth 5) | Set-Content -LiteralPath $DXCfgArq -Encoding UTF8 }

# Endereço deste computador na rede (para celulares e outros PCs)
function IpLocal {
  try {
    $ip = Get-NetIPAddress -AddressFamily IPv4 -ErrorAction Stop |
      Where-Object { $_.IPAddress -notlike '127.*' -and $_.IPAddress -notlike '169.254.*' -and $_.PrefixOrigin -in @('Dhcp', 'Manual') } |
      Sort-Object -Property @{ Expression = { if ($_.InterfaceAlias -match 'Wi-?Fi|Ethernet') { 0 } else { 1 } } } |
      Select-Object -First 1 -ExpandProperty IPAddress
    if ($ip) { return $ip }
  } catch {}
  return '127.0.0.1'
}

function UrlsAdmin($c) {
  $dono = Decifrar $c.senhaDono
  $base = "postgres://dxcore:$dono@127.0.0.1:$($c.portaBanco)"
  return @{ Postgres = "$base/postgres"; Banco = "$base/dxcore_finance" }
}

# Roda um script Node do sistema na MESMA janela (perguntas e mensagens aparecem normalmente).
# Retorna o código de saída.
function RodarNode([string]$script, [hashtable]$env, [string[]]$argumentos = @()) {
  $antigos = @{}
  foreach ($k in $env.Keys) { $antigos[$k] = [Environment]::GetEnvironmentVariable($k, 'Process'); [Environment]::SetEnvironmentVariable($k, $env[$k], 'Process') }
  try {
    $partes = @('"' + (Join-Path $DXSistema $script) + '"') + ($argumentos | ForEach-Object { '"' + ($_ -replace '"', '') + '"' })
    $p = Start-Process -FilePath $DXNode -ArgumentList ($partes -join ' ') -WorkingDirectory $DXSistema -NoNewWindow -Wait -PassThru
    return $p.ExitCode
  } finally {
    foreach ($k in $antigos.Keys) { [Environment]::SetEnvironmentVariable($k, $antigos[$k], 'Process') }
  }
}

# Roda um programa e espera ELE terminar (sem prender a janela atual nem tratar avisos como erro).
# Sem $saida: abre numa janela escondida própria (o banco não morre se esta janela for fechada).
# Com $saida: grava a saída nesse arquivo.
function Executar([string]$exe, [string]$argumentos, [string]$saida = $null) {
  $p = @{ FilePath = $exe; ArgumentList = $argumentos; PassThru = $true }
  if ($saida) { $p.RedirectStandardOutput = $saida; $p.RedirectStandardError = ($saida + '.erros'); $p.NoNewWindow = $true }
  else { $p.WindowStyle = 'Hidden' }
  $proc = Start-Process @p
  $null = $proc.Handle   # necessário para o Windows PowerShell guardar o código de saída
  $proc.WaitForExit()
  return $proc.ExitCode
}

function BancoLigado($c) {
  return ((Executar (Join-Path $DXPg 'pg_ctl.exe') ('status -D "' + $DXBanco + '"')) -eq 0)
}
function LigarBanco($c) {
  if (BancoLigado $c) { return }
  $log = Join-Path $DXLog 'banco.log'
  # aviso "outro servidor pode estar executando" (sobra de um desligamento brusco) é normal: o pg_ctl resolve sozinho
  $cod = Executar (Join-Path $DXPg 'pg_ctl.exe') ('start -w -t 90 -D "' + $DXBanco + '" -l "' + $log + '" -o "-p ' + $c.portaBanco + '"')
  if (-not (BancoLigado $c)) { throw "O banco de dados não iniciou (código $cod). Veja $log" }
}
function DesligarBanco {
  if (Test-Path (Join-Path $DXPg 'pg_ctl.exe')) {
    Executar (Join-Path $DXPg 'pg_ctl.exe') ('stop -w -t 60 -m fast -D "' + $DXBanco + '"') | Out-Null
  }
  # garante: encerra qualquer processo do banco deste programa que tenha sobrado
  Get-Process postgres, pg_ctl -ErrorAction SilentlyContinue | Where-Object { $_.Path -and $_.Path.StartsWith($DXPg, [StringComparison]::OrdinalIgnoreCase) } |
    Stop-Process -Force -ErrorAction SilentlyContinue
}

# Instalação que ficou pela metade (ex.: janela fechada no meio): limpa tudo para recomeçar.
function LimparInstalacao {
  PararSistema
  DesligarBanco
  Start-Sleep -Seconds 2
  foreach ($f in @((Join-Path ([Environment]::GetFolderPath('Desktop')) 'DXCORE Finance.lnk'),
                   (Join-Path ([Environment]::GetFolderPath('StartMenu')) 'Programs\DXCORE Finance.lnk'),
                   (Join-Path ([Environment]::GetFolderPath('Startup')) 'DXCORE Finance (servidor).lnk'))) { Remove-Item $f -Force -ErrorAction SilentlyContinue }
  for ($i = 0; $i -lt 5 -and (Test-Path $DX); $i++) {
    try { Remove-Item $DX -Recurse -Force -ErrorAction Stop } catch { Start-Sleep -Seconds 2 }
  }
  if (Test-Path $DX) { throw "Não foi possível apagar $DX. Reinicie o computador e rode o INSTALAR.bat de novo." }
}

function SistemaResponde($c) {
  try { $r = Invoke-WebRequest -UseBasicParsing -TimeoutSec 3 -Uri "http://127.0.0.1:$($c.porta)/" ; return ($r.StatusCode -eq 200) } catch { return $false }
}

function Navegador {
  foreach ($k in @('HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\msedge.exe', 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\msedge.exe',
                   'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe', 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe')) {
    try { $v = (Get-ItemProperty -Path $k -ErrorAction Stop).'(default)'; if ($v -and (Test-Path $v)) { return $v } } catch {}
  }
  $c = @("${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe", "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe",
         "$env:ProgramFiles\Google\Chrome\Application\chrome.exe", "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe")
  return ($c | Where-Object { $_ -and (Test-Path $_) } | Select-Object -First 1)
}

# Para o servidor (Node + supervisor). O banco é desligado à parte.
function PararSistema {
  try {
    Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" | Where-Object { $_.CommandLine -like '*DXCORE-Finance*iniciar.ps1*' } |
      ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
    Get-Process node -ErrorAction SilentlyContinue | Where-Object { $_.Path -eq $DXNode } | Stop-Process -Force -ErrorAction SilentlyContinue
  } catch { Log ('parar: ' + $_.Exception.Message) }
}

function Atalho([string]$arquivo, [string]$vbs, [string]$descricao) {
  $ws = New-Object -ComObject WScript.Shell
  $s = $ws.CreateShortcut($arquivo)
  $s.TargetPath = Join-Path $env:WINDIR 'System32\wscript.exe'
  $s.Arguments = '"' + (Join-Path $DXProg "windows\$vbs") + '"'
  $s.WorkingDirectory = Join-Path $DXProg 'windows'
  $s.IconLocation = (Join-Path $DXProg 'windows\DXCORE-Finance.ico') + ',0'
  $s.Description = $descricao
  $s.Save()
}

function FazerBackup($c, [string]$motivo = 'diario') {
  if (-not (Test-Path $DXBackups)) { New-Item -ItemType Directory -Path $DXBackups -Force | Out-Null }
  $arq = Join-Path $DXBackups ('dxcore-finance-' + (Get-Date -Format 'yyyy-MM-dd_HHmm') + "-$motivo.dxbak")
  $u = UrlsAdmin $c
  $cod = RodarNode 'scripts\backup-dados.mjs' @{ DATABASE_URL_ADMIN = $u.Banco } @($arq)
  if ($cod -ne 0) { throw 'backup falhou' }
  # mantém 30 dias
  Get-ChildItem $DXBackups -Filter 'dxcore-finance-*.dxbak' | Where-Object { $_.LastWriteTime -lt (Get-Date).AddDays(-30) } | Remove-Item -Force -ErrorAction SilentlyContinue
  # cópia fora deste computador, se o OneDrive estiver instalado
  if ($env:OneDrive -and (Test-Path $env:OneDrive)) {
    $nuvem = Join-Path $env:OneDrive 'DXCORE-Finance-backups'
    if (-not (Test-Path $nuvem)) { New-Item -ItemType Directory -Path $nuvem -Force | Out-Null }
    Copy-Item $arq $nuvem -Force
    Get-ChildItem $nuvem -Filter 'dxcore-finance-*.dxbak' | Where-Object { $_.LastWriteTime -lt (Get-Date).AddDays(-30) } | Remove-Item -Force -ErrorAction SilentlyContinue
  }
  Log ('backup: ' + $arq)
  return $arq
}
