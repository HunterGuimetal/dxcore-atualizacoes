﻿# DXCORE Finance - instalador para Windows
# Uso: clique duas vezes em INSTALAR.bat (na pasta descompactada do ZIP)
$pacote = Split-Path -Parent $PSScriptRoot
. (Join-Path $PSScriptRoot 'comum.ps1')
$Host.UI.RawUI.WindowTitle = 'DXCORE Finance - instalação'
function Passo([string]$m) { Write-Host ''; Write-Host "-> $m" -ForegroundColor Cyan }
function Ok([string]$m) { Write-Host "   OK  $m" -ForegroundColor Green }
function Falhar([string]$m) { Write-Host ''; Write-Host "ERRO: $m" -ForegroundColor Red; Log ('instalação: ' + $m); exit 1 }

Write-Host ''
Write-Host '  =====================================' -ForegroundColor DarkYellow
Write-Host '    DXCORE Finance  ·  instalação'       -ForegroundColor DarkYellow
Write-Host '  =====================================' -ForegroundColor DarkYellow
Write-Host ''
Write-Host 'Este computador vai funcionar como o servidor do DXCORE Finance.'
Write-Host 'Ele precisa ficar ligado para os outros computadores e celulares da empresa acessarem.'

if (-not [Environment]::Is64BitOperatingSystem) { Falhar 'É preciso Windows de 64 bits.' }
if (Test-Path $DXCfgArq) {
  $cfgAntiga = $null; try { $cfgAntiga = LerConfig } catch {}
  if ($cfgAntiga -and $cfgAntiga.concluido) { Falhar "O DXCORE Finance já está instalado neste computador. Para atualizar, use o ATUALIZAR.bat." }
  Write-Host ''
  Write-Host 'Encontrei uma instalação que não terminou. Limpando para recomeçar...' -ForegroundColor Yellow
  try { LimparInstalacao; Write-Host '   OK  instalação anterior removida' -ForegroundColor Green } catch { Falhar $_.Exception.Message }
}

try {
  # 1. Copiar o programa
  Passo 'Copiando o programa'
  foreach ($d in @($DX, $DXProg, $DXLog, (Split-Path $DXBanco))) { if (-not (Test-Path $d)) { New-Item -ItemType Directory -Path $d -Force | Out-Null } }
  Get-ChildItem -Path $pacote -Recurse -File | Unblock-File -ErrorAction SilentlyContinue
  foreach ($d in @('sistema', 'runtime', 'windows')) { Copy-Item -Path (Join-Path $pacote $d) -Destination $DXProg -Recurse -Force }
  Copy-Item (Join-Path $pacote 'versao.txt') $DXProg -Force
  Ok $DXProg

  Passo 'Preparando o banco de dados (PostgreSQL)'
  Expand-Archive -Path (Join-Path $pacote 'runtime\pgsql.zip') -DestinationPath $DXProg -Force
  Remove-Item (Join-Path $DXProg 'runtime\pgsql.zip') -Force -ErrorAction SilentlyContinue
  Ok 'arquivos do banco copiados'

  # 2. Permissões do Windows (uma vez): firewall da rede interna e Visual C++
  Passo 'Liberando o acesso pela rede da empresa (o Windows vai pedir permissão)'
  $vcOk = $false
  foreach ($k in @('HKLM:\SOFTWARE\Microsoft\VisualStudio\14.0\VC\Runtimes\x64', 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\VisualStudio\14.0\VC\Runtimes\x64')) {
    try { if ((Get-ItemProperty -Path $k -ErrorAction Stop).Installed -eq 1) { $vcOk = $true } } catch {}
  }
  $porta = 47820
  $cmd = "netsh advfirewall firewall delete rule name=DXCORE-Finance | Out-Null; " +
         "netsh advfirewall firewall add rule name=DXCORE-Finance dir=in action=allow protocol=TCP localport=$porta profile=private,domain | Out-Null; "
  if (-not $vcOk) {
    Write-Host '   Instalando o Microsoft Visual C++ (necessário para o banco de dados)...'
    $vc = Join-Path $env:TEMP 'vc_redist.x64.exe'
    Invoke-WebRequest -UseBasicParsing -Uri 'https://aka.ms/vs/17/release/vc_redist.x64.exe' -OutFile $vc
    $cmd += "Start-Process -FilePath '$vc' -ArgumentList '/install','/quiet','/norestart' -Wait; "
  }
  try {
    Start-Process powershell.exe -Verb RunAs -Wait -WindowStyle Hidden -ArgumentList '-NoProfile', '-ExecutionPolicy', 'Bypass', '-Command', $cmd
    Ok 'acesso pela rede liberado'
  } catch {
    Write-Host '   Permissão negada: o sistema vai funcionar só neste computador. Rode o INSTALAR de novo depois para liberar a rede.' -ForegroundColor Yellow
  }

  # 3. Senhas e banco
  Passo 'Criando o banco de dados'
  $senhaDono = SenhaAleatoria; $senhaApp = SenhaAleatoria
  $c = [pscustomobject]@{ porta = $porta; portaBanco = 47821; senhaDono = (Cifrar $senhaDono); senhaApp = (Cifrar $senhaApp); versao = (Get-Content (Join-Path $DXProg 'versao.txt')).Trim(); instaladoEm = (Get-Date -Format s) }
  $pw = Join-Path $env:TEMP ('dx-' + [guid]::NewGuid() + '.txt')
  [IO.File]::WriteAllText($pw, $senhaDono)
  try {
    $codInit = Executar (Join-Path $DXPg 'initdb.exe') ('-D "' + $DXBanco + '" -U dxcore -A scram-sha-256 "--pwfile=' + $pw + '" -E UTF8 --locale=C --no-instructions') (Join-Path $DXLog 'initdb.log')
    if ($codInit -ne 0) { throw "initdb falhou (veja $DXLog\initdb.log). Se o erro citar VCRUNTIME140.dll, instale o Microsoft Visual C++ e rode de novo." }
  } finally { Remove-Item $pw -Force -ErrorAction SilentlyContinue }
  Add-Content -Path (Join-Path $DXBanco 'postgresql.conf') -Encoding ASCII -Value @"

# --- DXCORE Finance ---
listen_addresses = '127.0.0.1'
port = $($c.portaBanco)
max_connections = 40
shared_buffers = 128MB
timezone = 'UTC'
log_timezone = 'America/Sao_Paulo'
"@
  SalvarConfig $c
  LigarBanco $c
  $u = UrlsAdmin $c
  $cod = RodarNode 'scripts\preparar-banco.mjs' @{ PG_ADMIN_URL = $u.Postgres; SENHA_APP = $senhaApp }
  if ($cod -ne 0) { throw 'Não foi possível preparar o banco de dados.' }
  Ok 'banco criado e protegido'

  # 4. Grupo, empresas e administrador
  Passo 'Cadastro das empresas e do administrador'
  $cod = RodarNode 'scripts\criar-grupo.mjs' @{ DATABASE_URL_ADMIN = $u.Banco }
  if ($cod -ne 0) { throw 'O cadastro não foi concluído. Rode o INSTALAR.bat de novo depois de desinstalar (veja o LEIA-ME).' }

  # 5. Atalhos e inicialização automática
  Passo 'Criando atalhos'
  Atalho (Join-Path ([Environment]::GetFolderPath('Desktop')) 'DXCORE Finance.lnk') 'abrir.vbs' 'Abrir o DXCORE Finance'
  $menu = Join-Path ([Environment]::GetFolderPath('StartMenu')) 'Programs'
  Atalho (Join-Path $menu 'DXCORE Finance.lnk') 'abrir.vbs' 'Abrir o DXCORE Finance'
  Atalho (Join-Path ([Environment]::GetFolderPath('Startup')) 'DXCORE Finance (servidor).lnk') 'iniciar.vbs' 'Liga o servidor do DXCORE Finance com o Windows'
  Ok 'Área de Trabalho, menu Iniciar e inicialização com o Windows'

  # 6. Ligar e abrir
  Passo 'Ligando o sistema'
  Start-Process -FilePath (Join-Path $env:WINDIR 'System32\wscript.exe') -ArgumentList ('"' + (Join-Path $DXProg 'windows\iniciar.vbs') + '"')
  $ok = $false
  for ($i = 0; $i -lt 80; $i++) { Start-Sleep -Milliseconds 750; if (SistemaResponde $c) { $ok = $true; break } }
  if (-not $ok) { throw "O sistema não respondeu. Veja $DXLog" }
  FazerBackup $c 'instalacao' | Out-Null
  $c | Add-Member -NotePropertyName concluido -NotePropertyValue $true -Force
  SalvarConfig $c
  $ip = IpLocal
  $acesso = @"
DXCORE Finance - como acessar
==============================
Neste computador:   atalho "DXCORE Finance" na Área de Trabalho
Outros computadores e celulares (mesma rede/Wi-Fi da empresa):
   http://${ip}:$porta
   http://$($env:COMPUTERNAME):$porta   (nos computadores Windows)

Este computador precisa ficar ligado. Backups diários em:
   $DXBackups
"@
  $acesso | Set-Content -Path (Join-Path ([Environment]::GetFolderPath('Desktop')) 'DXCORE Finance - acesso.txt') -Encoding UTF8
  Write-Host ''
  Write-Host '  =====================================' -ForegroundColor Green
  Write-Host '    Instalação concluída!' -ForegroundColor Green
  Write-Host '  =====================================' -ForegroundColor Green
  Write-Host $acesso
  Write-Host '(Essas informações também ficaram no arquivo "DXCORE Finance - acesso.txt" na Área de Trabalho.)'
  Start-Process -FilePath (Join-Path $env:WINDIR 'System32\wscript.exe') -ArgumentList ('"' + (Join-Path $DXProg 'windows\abrir.vbs') + '"')
  Log 'instalação concluída'
} catch {
  Falhar $_.Exception.Message
}
