﻿# DXCORE Finance - voltar para a versão anterior (se uma atualização der problema)
. (Join-Path $PSScriptRoot 'comum.ps1')
. (Join-Path $PSScriptRoot 'atualizacao.ps1')
if (-not (Test-Path $DXCfgArq)) { Write-Host 'O DXCORE Finance não está instalado neste computador.' -ForegroundColor Red; exit 1 }
if (-not (Test-Path (Join-Path $DXAnterior 'sistema\server.js'))) { Write-Host 'Não há versão anterior guardada.' -ForegroundColor Yellow; exit 0 }
$ant = (Get-Content (Join-Path $DXAnterior 'versao.txt') -Raw).Trim()
Write-Host "Versão atual: $(VersaoInstalada)  ->  voltar para: $ant"
if ((Read-Host 'Digite VOLTAR para confirmar') -ne 'VOLTAR') { Write-Host 'Cancelado.'; exit 0 }
try {
  PararSistema; Start-Sleep -Seconds 2
  VoltarVersaoAnterior
  Start-Process -FilePath (Join-Path $env:WINDIR 'System32\wscript.exe') -ArgumentList ('"' + (Join-Path $DXProg 'windows\abrir.vbs') + '"')
  Write-Host "Pronto: voltou para a versão $ant." -ForegroundColor Green
} catch { Write-Host ('ERRO: ' + $_.Exception.Message) -ForegroundColor Red; exit 1 }
