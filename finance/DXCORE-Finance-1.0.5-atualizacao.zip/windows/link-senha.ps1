﻿# DXCORE Finance - emergência: link de nova senha (ex.: o administrador esqueceu a senha)
. (Join-Path $PSScriptRoot 'comum.ps1')
$email = Read-Host 'E-mail do usuário'
$c = LerConfig
LigarBanco $c
$u = UrlsAdmin $c
RodarNode 'scripts\link-senha.mjs' @{ DATABASE_URL_ADMIN = $u.Banco; APP_URL = "http://localhost:$($c.porta)" } @($email) | Out-Null
Read-Host 'Copie o link acima e pressione Enter para fechar'
