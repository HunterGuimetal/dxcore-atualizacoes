-- DXCORE Finance · 0004 · Importação de extrato (OFX) e conciliação

CREATE TYPE situacao_movimento AS ENUM ('pendente', 'conciliado', 'ignorado');

CREATE TABLE importacao_extrato (
  id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  grupo_id          uuid NOT NULL REFERENCES grupo(id),
  empresa_id        uuid NOT NULL REFERENCES empresa(id),
  conta_bancaria_id uuid NOT NULL REFERENCES conta_bancaria(id),
  nome_arquivo      text NOT NULL,
  hash_arquivo      text NOT NULL,
  banco_id          text,
  conta_extrato     text,
  inicio            date,
  fim               date,
  saldo_final       bigint,
  data_saldo        date,
  total             int NOT NULL,
  novos             int NOT NULL,
  criado_por        uuid,
  criado_em         timestamptz NOT NULL DEFAULT now(),
  atualizado_em     timestamptz NOT NULL DEFAULT now(),
  excluido_em       timestamptz,
  excluido_por      uuid
);
CREATE UNIQUE INDEX importacao_hash ON importacao_extrato (conta_bancaria_id, hash_arquivo) WHERE excluido_em IS NULL;

CREATE TABLE movimento_bancario (
  id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  grupo_id          uuid NOT NULL REFERENCES grupo(id),
  empresa_id        uuid NOT NULL REFERENCES empresa(id),
  conta_bancaria_id uuid NOT NULL REFERENCES conta_bancaria(id),
  importacao_id     uuid REFERENCES importacao_extrato(id),
  chave             text NOT NULL,        -- anti-duplicidade entre importações
  fitid             text,
  data              date NOT NULL,
  valor             bigint NOT NULL CHECK (valor <> 0),   -- + entrada / − saída (centavos)
  descricao         text NOT NULL,
  tipo_extrato      text,
  documento         text,
  situacao          situacao_movimento NOT NULL DEFAULT 'pendente',
  sugestao          jsonb,                -- melhor sugestão do motor (para revisão)
  alternativas      jsonb,
  confianca         int,
  automatico        boolean NOT NULL DEFAULT false,
  conciliado_em     timestamptz,
  conciliado_por    uuid,
  criado_em         timestamptz NOT NULL DEFAULT now(),
  atualizado_em     timestamptz NOT NULL DEFAULT now(),
  excluido_em       timestamptz,
  excluido_por      uuid
);
CREATE UNIQUE INDEX movimento_chave ON movimento_bancario (conta_bancaria_id, chave) WHERE excluido_em IS NULL;
CREATE INDEX movimento_pendente ON movimento_bancario (empresa_id, situacao, data) WHERE excluido_em IS NULL;

-- Vínculo movimento ↔ baixa. Um movimento pode quitar várias baixas; cada baixa só um movimento.
CREATE TABLE conciliacao (
  id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  grupo_id          uuid NOT NULL REFERENCES grupo(id),
  empresa_id        uuid NOT NULL REFERENCES empresa(id),
  movimento_id      uuid NOT NULL REFERENCES movimento_bancario(id),
  baixa_id          uuid NOT NULL REFERENCES baixa(id),
  criou_baixa       boolean NOT NULL,     -- a baixa nasceu da conciliação (desfazer estorna)
  criou_titulo_id   uuid REFERENCES titulo(id),  -- idem para lançamento novo
  automatico        boolean NOT NULL DEFAULT false,
  criado_por        uuid,
  criado_em         timestamptz NOT NULL DEFAULT now(),
  atualizado_em     timestamptz NOT NULL DEFAULT now(),
  excluido_em       timestamptz,          -- = desfeita
  excluido_por      uuid
);
CREATE UNIQUE INDEX conciliacao_baixa ON conciliacao (baixa_id) WHERE excluido_em IS NULL;
CREATE INDEX conciliacao_movimento ON conciliacao (movimento_id) WHERE excluido_em IS NULL;

-- O que o sistema aprendeu com as confirmações do usuário.
CREATE TABLE regra_categorizacao (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  grupo_id       uuid NOT NULL REFERENCES grupo(id),
  empresa_id     uuid NOT NULL REFERENCES empresa(id),
  padrao         text NOT NULL,
  categoria_id   uuid NOT NULL REFERENCES categoria(id),
  pessoa_id      uuid REFERENCES pessoa(id),
  vezes          int NOT NULL DEFAULT 1,
  ultima_em      timestamptz NOT NULL DEFAULT now(),
  criado_em      timestamptz NOT NULL DEFAULT now(),
  atualizado_em  timestamptz NOT NULL DEFAULT now(),
  excluido_em    timestamptz,
  excluido_por   uuid
);
CREATE UNIQUE INDEX regra_unica ON regra_categorizacao (empresa_id, padrao, categoria_id) WHERE excluido_em IS NULL;

-- Integridade: tudo da mesma empresa; baixa vinculada precisa ser da mesma conta do movimento.
CREATE FUNCTION app.validar_movimento() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  PERFORM app.exigir_mesma_empresa('conta_bancaria', NEW.conta_bancaria_id, NEW.empresa_id);
  PERFORM app.exigir_mesma_empresa('importacao_extrato', NEW.importacao_id, NEW.empresa_id);
  RETURN NEW;
END $$;
CREATE TRIGGER movimento_validar BEFORE INSERT OR UPDATE ON movimento_bancario FOR EACH ROW EXECUTE FUNCTION app.validar_movimento();

CREATE FUNCTION app.validar_importacao() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  PERFORM app.exigir_mesma_empresa('conta_bancaria', NEW.conta_bancaria_id, NEW.empresa_id);
  RETURN NEW;
END $$;
CREATE TRIGGER importacao_validar BEFORE INSERT OR UPDATE ON importacao_extrato FOR EACH ROW EXECUTE FUNCTION app.validar_importacao();

CREATE FUNCTION app.validar_conciliacao() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE v_conta_mov uuid; v_conta_baixa uuid;
BEGIN
  PERFORM app.exigir_mesma_empresa('movimento_bancario', NEW.movimento_id, NEW.empresa_id);
  PERFORM app.exigir_mesma_empresa('baixa', NEW.baixa_id, NEW.empresa_id);
  SELECT conta_bancaria_id INTO v_conta_mov FROM movimento_bancario WHERE id = NEW.movimento_id;
  SELECT conta_bancaria_id INTO v_conta_baixa FROM baixa WHERE id = NEW.baixa_id;
  IF v_conta_mov IS DISTINCT FROM v_conta_baixa THEN
    RAISE EXCEPTION 'A baixa é de outra conta bancária.' USING ERRCODE = 'check_violation';
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER conciliacao_validar BEFORE INSERT ON conciliacao FOR EACH ROW EXECUTE FUNCTION app.validar_conciliacao();

CREATE FUNCTION app.validar_regra() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  PERFORM app.exigir_mesma_empresa('categoria', NEW.categoria_id, NEW.empresa_id);
  PERFORM app.exigir_mesma_empresa('pessoa', NEW.pessoa_id, NEW.empresa_id);
  RETURN NEW;
END $$;
CREATE TRIGGER regra_validar BEFORE INSERT OR UPDATE ON regra_categorizacao FOR EACH ROW EXECUTE FUNCTION app.validar_regra();

DO $$
DECLARE t text;
BEGIN
  FOREACH t IN ARRAY ARRAY['importacao_extrato', 'movimento_bancario', 'conciliacao', 'regra_categorizacao'] LOOP
    EXECUTE format('CREATE TRIGGER %1$s_atualizado BEFORE UPDATE ON %1$I FOR EACH ROW EXECUTE FUNCTION app.tocar_atualizado_em()', t);
    EXECUTE format('CREATE TRIGGER %1$s_sem_delete BEFORE DELETE ON %1$I FOR EACH ROW EXECUTE FUNCTION app.proibir_exclusao_fisica()', t);
    EXECUTE format('ALTER TABLE %I ENABLE ROW LEVEL SECURITY', t);
    EXECUTE format($p$CREATE POLICY %1$s_isolado ON %1$I FOR ALL TO dxcore_app
      USING (grupo_id = app.grupo_atual() AND empresa_id = ANY (app.empresas_permitidas()))
      WITH CHECK (grupo_id = app.grupo_atual() AND empresa_id = ANY (app.empresas_permitidas()))$p$, t);
    EXECUTE format('GRANT SELECT, INSERT, UPDATE ON %I TO dxcore_app', t);
  END LOOP;
END $$;
-- auditoria: importação, conciliação e regras (movimentos são dado do banco; mudanças relevantes ficam na conciliação)
CREATE TRIGGER importacao_extrato_auditoria AFTER INSERT OR UPDATE ON importacao_extrato FOR EACH ROW EXECUTE FUNCTION app.auditar();
CREATE TRIGGER conciliacao_auditoria AFTER INSERT OR UPDATE ON conciliacao FOR EACH ROW EXECUTE FUNCTION app.auditar();
CREATE TRIGGER regra_categorizacao_auditoria AFTER INSERT OR UPDATE ON regra_categorizacao FOR EACH ROW EXECUTE FUNCTION app.auditar();
