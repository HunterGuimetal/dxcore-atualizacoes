-- DXCORE Finance · 0005 · Convites, redefinição de senha e gestão de usuários
-- Tokens guardados só como hash (SHA-256). Acesso apenas por funções controladas.

CREATE TYPE tipo_token AS ENUM ('convite', 'redefinicao');

CREATE TABLE token_senha (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  usuario_id  uuid NOT NULL REFERENCES usuario(id),
  token_hash  bytea NOT NULL UNIQUE,
  tipo        tipo_token NOT NULL,
  expira_em   timestamptz NOT NULL,
  usado_em    timestamptz,
  criado_por  uuid,               -- null = pedido pelo próprio usuário ("esqueci")
  criado_em   timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX token_senha_usuario ON token_senha (usuario_id, criado_em DESC);
CREATE TRIGGER token_senha_sem_delete BEFORE DELETE ON token_senha FOR EACH ROW EXECUTE FUNCTION app.proibir_exclusao_fisica();

-- Administrador gera convite/link para um usuário DO PRÓPRIO GRUPO. Invalida links anteriores.
CREATE FUNCTION app.criar_token_senha(p_usuario uuid, p_hash bytea, p_tipo tipo_token, p_validade interval)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public, app AS $$
BEGIN
  IF app.grupo_atual() IS NULL OR NOT EXISTS (
       SELECT 1 FROM usuario WHERE id = p_usuario AND grupo_id = app.grupo_atual() AND excluido_em IS NULL) THEN
    RAISE EXCEPTION 'Usuário não encontrado neste grupo.' USING ERRCODE = 'insufficient_privilege';
  END IF;
  UPDATE token_senha SET usado_em = now() WHERE usuario_id = p_usuario AND usado_em IS NULL;
  INSERT INTO token_senha (usuario_id, token_hash, tipo, expira_em, criado_por)
  VALUES (p_usuario, p_hash, p_tipo, now() + p_validade, app.usuario_atual());
END $$;

-- "Esqueci a senha": sem login. Devolve nome/e-mail para enviar o link, ou nada.
-- Limite: 3 pedidos por hora por usuário (contra abuso).
CREATE FUNCTION app.solicitar_redefinicao(p_email text, p_hash bytea, p_validade interval)
RETURNS TABLE (nome text, email text) LANGUAGE plpgsql SECURITY DEFINER SET search_path = public, app AS $$
DECLARE v_id uuid; v_nome text; v_email text;
BEGIN
  SELECT u.id, u.nome, u.email::text INTO v_id, v_nome, v_email FROM usuario u
   WHERE u.email = p_email::citext AND u.ativo AND u.excluido_em IS NULL;
  IF v_id IS NULL THEN RETURN; END IF;
  IF (SELECT count(*) FROM token_senha WHERE usuario_id = v_id AND criado_por IS NULL AND criado_em > now() - interval '1 hour') >= 3 THEN
    RETURN;
  END IF;
  INSERT INTO token_senha (usuario_id, token_hash, tipo, expira_em) VALUES (v_id, p_hash, 'redefinicao', now() + p_validade);
  RETURN QUERY SELECT v_nome, v_email;
END $$;

-- Confere se o link ainda vale (para mostrar a tela).
CREATE FUNCTION app.validar_token_senha(p_hash bytea)
RETURNS TABLE (nome text, email text, tipo tipo_token) LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public, app AS $$
  SELECT u.nome, u.email::text, t.tipo FROM token_senha t JOIN usuario u ON u.id = t.usuario_id
   WHERE t.token_hash = p_hash AND t.usado_em IS NULL AND t.expira_em > now() AND u.ativo AND u.excluido_em IS NULL
$$;

-- Usa o link: grava a nova senha, invalida o link e encerra as sessões abertas do usuário.
CREATE FUNCTION app.consumir_token_senha(p_hash bytea, p_senha_hash text)
RETURNS text LANGUAGE plpgsql SECURITY DEFINER SET search_path = public, app AS $$
DECLARE v_usuario uuid; v_email text;
BEGIN
  SELECT t.usuario_id, u.email::text INTO v_usuario, v_email FROM token_senha t JOIN usuario u ON u.id = t.usuario_id
   WHERE t.token_hash = p_hash AND t.usado_em IS NULL AND t.expira_em > now() AND u.ativo AND u.excluido_em IS NULL
   FOR UPDATE OF t;
  IF v_usuario IS NULL THEN RETURN NULL; END IF;
  UPDATE token_senha SET usado_em = now() WHERE token_hash = p_hash;
  UPDATE usuario SET senha_hash = p_senha_hash WHERE id = v_usuario;
  UPDATE sessao SET revogada_em = now() WHERE usuario_id = v_usuario AND revogada_em IS NULL;
  -- desbloqueia o login (zera as falhas recentes)
  INSERT INTO tentativa_login (email, sucesso) VALUES (v_email, true);
  RETURN v_email;
END $$;

-- Ao trocar a própria senha: encerra as outras sessões (mantém a atual).
CREATE FUNCTION app.revogar_outras_sessoes(p_manter bytea) RETURNS void
LANGUAGE sql SECURITY DEFINER SET search_path = public, app AS $$
  UPDATE sessao SET revogada_em = now()
   WHERE usuario_id = app.usuario_atual() AND revogada_em IS NULL AND token_hash <> p_manter
$$;

-- Último acesso (para a lista de usuários)
CREATE FUNCTION app.ultimos_acessos() RETURNS TABLE (usuario_id uuid, ultimo timestamptz)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public, app AS $$
  SELECT s.usuario_id, max(s.criada_em) FROM sessao s JOIN usuario u ON u.id = s.usuario_id
   WHERE u.grupo_id = app.grupo_atual() GROUP BY s.usuario_id
$$;

-- Bloqueio de login passa a considerar só falhas DEPOIS do último sucesso
CREATE OR REPLACE FUNCTION app.contar_falhas_recentes(p_email text) RETURNS bigint
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public, app AS $$
  SELECT count(*) FROM tentativa_login
   WHERE email = p_email::citext AND NOT sucesso AND em > now() - interval '15 minutes'
     AND em > coalesce((SELECT max(em) FROM tentativa_login WHERE email = p_email::citext AND sucesso), '-infinity')
$$;

REVOKE ALL ON FUNCTION app.criar_token_senha(uuid, bytea, tipo_token, interval), app.solicitar_redefinicao(text, bytea, interval),
  app.validar_token_senha(bytea), app.consumir_token_senha(bytea, text), app.revogar_outras_sessoes(bytea), app.ultimos_acessos() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION app.criar_token_senha(uuid, bytea, tipo_token, interval), app.solicitar_redefinicao(text, bytea, interval),
  app.validar_token_senha(bytea), app.consumir_token_senha(bytea, text), app.revogar_outras_sessoes(bytea), app.ultimos_acessos() TO dxcore_app;
