-- DXCORE Finance · 0002 · Cadastros: contas bancárias, plano de contas, centros de custo, pessoas

CREATE EXTENSION IF NOT EXISTS pg_trgm;   -- busca rápida por nome ("contém")
CREATE EXTENSION IF NOT EXISTS unaccent;  -- busca sem acento

CREATE FUNCTION app.sem_acento(text) RETURNS text LANGUAGE sql IMMUTABLE PARALLEL SAFE AS
$$ SELECT lower(public.unaccent('public.unaccent'::regdictionary, $1)) $$;
GRANT EXECUTE ON FUNCTION app.sem_acento(text) TO dxcore_app;

CREATE TYPE tipo_conta AS ENUM ('corrente', 'poupanca', 'investimento', 'caixa', 'cartao');
CREATE TYPE natureza AS ENUM ('receita', 'despesa');
-- Linha da DRE gerencial em que a categoria entra.
CREATE TYPE grupo_dre AS ENUM (
  'receita_bruta', 'deducoes', 'custos', 'despesas_operacionais',
  'receitas_financeiras', 'despesas_financeiras', 'impostos_lucro',
  'nao_operacional', 'fora_dre'
);

CREATE TABLE conta_bancaria (
  id                 uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  grupo_id           uuid NOT NULL REFERENCES grupo(id),
  empresa_id         uuid NOT NULL REFERENCES empresa(id),
  nome               text NOT NULL,
  tipo               tipo_conta NOT NULL DEFAULT 'corrente',
  banco_codigo       char(3) CHECK (banco_codigo ~ '^\d{3}$'),
  agencia            text,
  numero             text,
  saldo_inicial      bigint NOT NULL DEFAULT 0,          -- centavos
  data_saldo_inicial date NOT NULL,
  ativo              boolean NOT NULL DEFAULT true,
  criado_em          timestamptz NOT NULL DEFAULT now(),
  atualizado_em      timestamptz NOT NULL DEFAULT now(),
  excluido_em        timestamptz,
  excluido_por       uuid
);
CREATE INDEX conta_bancaria_empresa ON conta_bancaria (empresa_id) WHERE excluido_em IS NULL;

CREATE TABLE categoria (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  grupo_id       uuid NOT NULL REFERENCES grupo(id),
  empresa_id     uuid NOT NULL REFERENCES empresa(id),
  pai_id         uuid REFERENCES categoria(id),
  codigo         text NOT NULL CHECK (codigo ~ '^\d+(\.\d+)*$'),
  nome           text NOT NULL,
  natureza       natureza NOT NULL,
  grupo_dre      grupo_dre NOT NULL,
  ativo          boolean NOT NULL DEFAULT true,
  criado_em      timestamptz NOT NULL DEFAULT now(),
  atualizado_em  timestamptz NOT NULL DEFAULT now(),
  excluido_em    timestamptz,
  excluido_por   uuid
);
CREATE UNIQUE INDEX categoria_codigo ON categoria (empresa_id, codigo) WHERE excluido_em IS NULL;

CREATE TABLE centro_custo (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  grupo_id       uuid NOT NULL REFERENCES grupo(id),
  empresa_id     uuid NOT NULL REFERENCES empresa(id),
  pai_id         uuid REFERENCES centro_custo(id),
  nome           text NOT NULL,
  ativo          boolean NOT NULL DEFAULT true,
  criado_em      timestamptz NOT NULL DEFAULT now(),
  atualizado_em  timestamptz NOT NULL DEFAULT now(),
  excluido_em    timestamptz,
  excluido_por   uuid
);
CREATE UNIQUE INDEX centro_custo_nome ON centro_custo (empresa_id, lower(nome)) WHERE excluido_em IS NULL;

-- Clientes e fornecedores (a mesma pessoa pode ser os dois).
-- LGPD: só o necessário para cobrar/pagar e emitir documentos.
CREATE TABLE pessoa (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  grupo_id       uuid NOT NULL REFERENCES grupo(id),
  empresa_id     uuid NOT NULL REFERENCES empresa(id),
  documento      text CHECK (documento ~ '^(\d{11}|\d{14})$'),  -- CPF ou CNPJ, só dígitos
  nome           text NOT NULL,
  nome_fantasia  text,
  eh_cliente     boolean NOT NULL DEFAULT false,
  eh_fornecedor  boolean NOT NULL DEFAULT false,
  email          text,
  telefone       text,
  cidade         text,
  uf             char(2),
  observacoes    text,
  ativo          boolean NOT NULL DEFAULT true,
  criado_em      timestamptz NOT NULL DEFAULT now(),
  atualizado_em  timestamptz NOT NULL DEFAULT now(),
  excluido_em    timestamptz,
  excluido_por   uuid,
  CHECK (eh_cliente OR eh_fornecedor)
);
CREATE UNIQUE INDEX pessoa_documento ON pessoa (empresa_id, documento) WHERE excluido_em IS NULL AND documento IS NOT NULL;
CREATE INDEX pessoa_busca ON pessoa USING gin (app.sem_acento(nome || ' ' || coalesce(nome_fantasia, '')) gin_trgm_ops);

-- Gatilhos padrão (auditoria, atualizado_em, sem DELETE) e RLS por empresa
DO $$
DECLARE t text;
BEGIN
  FOREACH t IN ARRAY ARRAY['conta_bancaria', 'categoria', 'centro_custo', 'pessoa'] LOOP
    EXECUTE format('CREATE TRIGGER %1$s_atualizado BEFORE UPDATE ON %1$I FOR EACH ROW EXECUTE FUNCTION app.tocar_atualizado_em()', t);
    EXECUTE format('CREATE TRIGGER %1$s_sem_delete BEFORE DELETE ON %1$I FOR EACH ROW EXECUTE FUNCTION app.proibir_exclusao_fisica()', t);
    EXECUTE format('CREATE TRIGGER %1$s_auditoria AFTER INSERT OR UPDATE ON %1$I FOR EACH ROW EXECUTE FUNCTION app.auditar()', t);
    EXECUTE format('ALTER TABLE %I ENABLE ROW LEVEL SECURITY', t);
    EXECUTE format($p$CREATE POLICY %1$s_isolado ON %1$I FOR ALL TO dxcore_app
      USING (grupo_id = app.grupo_atual() AND empresa_id = ANY (app.empresas_permitidas()))
      WITH CHECK (grupo_id = app.grupo_atual() AND empresa_id = ANY (app.empresas_permitidas()))$p$, t);
    EXECUTE format('GRANT SELECT, INSERT, UPDATE ON %I TO dxcore_app', t);
  END LOOP;
END $$;

-- Pai precisa ser da mesma empresa
CREATE FUNCTION app.pai_mesma_empresa() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE v uuid;
BEGIN
  IF NEW.pai_id IS NULL THEN RETURN NEW; END IF;
  IF NEW.pai_id = NEW.id THEN RAISE EXCEPTION 'Um item não pode ser pai de si mesmo.'; END IF;
  EXECUTE format('SELECT empresa_id FROM %I WHERE id = $1', TG_TABLE_NAME) INTO v USING NEW.pai_id;
  IF v IS DISTINCT FROM NEW.empresa_id THEN RAISE EXCEPTION 'O item pai precisa ser da mesma empresa.'; END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER categoria_pai BEFORE INSERT OR UPDATE OF pai_id ON categoria FOR EACH ROW EXECUTE FUNCTION app.pai_mesma_empresa();
CREATE TRIGGER centro_custo_pai BEFORE INSERT OR UPDATE OF pai_id ON centro_custo FOR EACH ROW EXECUTE FUNCTION app.pai_mesma_empresa();

-- ---------- Plano de contas padrão para indústria/metalurgia ----------
-- Criado automaticamente para cada empresa nova. Cada empresa ajusta o seu.
CREATE FUNCTION app.criar_plano_padrao(p_empresa uuid) RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public, app AS $$
DECLARE v_grupo uuid;
BEGIN
  SELECT grupo_id INTO v_grupo FROM empresa WHERE id = p_empresa;
  IF EXISTS (SELECT 1 FROM categoria WHERE empresa_id = p_empresa) THEN RETURN; END IF;

  INSERT INTO categoria (grupo_id, empresa_id, codigo, nome, natureza, grupo_dre)
  SELECT v_grupo, p_empresa, codigo, nome, natureza::natureza, dre::grupo_dre FROM (VALUES
    ('1',    'Receitas',                                         'receita', 'receita_bruta'),
    ('1.1',  'Venda de produtos',                                'receita', 'receita_bruta'),
    ('1.2',  'Serviços (corte, dobra, solda, usinagem)',         'receita', 'receita_bruta'),
    ('1.3',  'Venda de sucata e retalhos',                       'receita', 'receita_bruta'),
    ('1.4',  'Rendimentos de aplicações',                        'receita', 'receitas_financeiras'),
    ('1.5',  'Juros e multas recebidos',                         'receita', 'receitas_financeiras'),
    ('1.6',  'Outras receitas',                                  'receita', 'nao_operacional'),
    ('2',    'Deduções da receita',                              'despesa', 'deducoes'),
    ('2.1',  'Impostos sobre vendas (ICMS, IPI, PIS, COFINS, ISS, Simples)', 'despesa', 'deducoes'),
    ('2.2',  'Devoluções e abatimentos',                         'despesa', 'deducoes'),
    ('2.3',  'Descontos concedidos',                             'despesa', 'deducoes'),
    ('3',    'Custos de produção',                               'despesa', 'custos'),
    ('3.1',  'Matéria-prima (chapas, perfis, tubos, barras)',    'despesa', 'custos'),
    ('3.2',  'Insumos e consumíveis (gases, eletrodos, discos, tintas)', 'despesa', 'custos'),
    ('3.3',  'Serviços terceirizados (galvanização, pintura, usinagem)', 'despesa', 'custos'),
    ('3.4',  'Mão de obra direta',                               'despesa', 'custos'),
    ('3.5',  'Energia elétrica da produção',                     'despesa', 'custos'),
    ('3.6',  'Manutenção de máquinas e ferramentas',             'despesa', 'custos'),
    ('3.7',  'Fretes de compra',                                 'despesa', 'custos'),
    ('4',    'Despesas operacionais',                            'despesa', 'despesas_operacionais'),
    ('4.1',  'Salários e encargos administrativos',              'despesa', 'despesas_operacionais'),
    ('4.2',  'Pró-labore',                                       'despesa', 'despesas_operacionais'),
    ('4.3',  'Benefícios (vale-transporte, alimentação, saúde)', 'despesa', 'despesas_operacionais'),
    ('4.4',  'Aluguel e condomínio',                             'despesa', 'despesas_operacionais'),
    ('4.5',  'Água, luz, telefone e internet',                   'despesa', 'despesas_operacionais'),
    ('4.6',  'Sistemas e software',                              'despesa', 'despesas_operacionais'),
    ('4.7',  'Contabilidade e serviços profissionais',           'despesa', 'despesas_operacionais'),
    ('4.8',  'Fretes de venda',                                  'despesa', 'despesas_operacionais'),
    ('4.9',  'Comissões de venda',                               'despesa', 'despesas_operacionais'),
    ('4.10', 'Marketing e propaganda',                           'despesa', 'despesas_operacionais'),
    ('4.11', 'Veículos e combustível',                           'despesa', 'despesas_operacionais'),
    ('4.12', 'Material de escritório, limpeza e EPI',            'despesa', 'despesas_operacionais'),
    ('4.13', 'Seguros',                                          'despesa', 'despesas_operacionais'),
    ('4.14', 'Impostos e taxas (IPTU, alvarás, licenças)',       'despesa', 'despesas_operacionais'),
    ('5',    'Despesas financeiras',                             'despesa', 'despesas_financeiras'),
    ('5.1',  'Tarifas bancárias',                                'despesa', 'despesas_financeiras'),
    ('5.2',  'Juros e multas por atraso',                        'despesa', 'despesas_financeiras'),
    ('5.3',  'IOF',                                              'despesa', 'despesas_financeiras'),
    ('5.4',  'Juros de empréstimos e financiamentos',            'despesa', 'despesas_financeiras'),
    ('5.5',  'Taxas de cartão e antecipação',                    'despesa', 'despesas_financeiras'),
    ('6',    'Impostos sobre o lucro',                           'despesa', 'impostos_lucro'),
    ('6.1',  'IRPJ',                                             'despesa', 'impostos_lucro'),
    ('6.2',  'CSLL',                                             'despesa', 'impostos_lucro'),
    ('7',    'Investimentos e financiamentos (fora da DRE)',     'despesa', 'fora_dre'),
    ('7.1',  'Compra de máquinas e equipamentos',                'despesa', 'fora_dre'),
    ('7.2',  'Pagamento de empréstimos (principal)',             'despesa', 'fora_dre'),
    ('7.3',  'Distribuição de lucros',                           'despesa', 'fora_dre'),
    ('8',    'Entradas fora da DRE',                             'receita', 'fora_dre'),
    ('8.1',  'Empréstimos e financiamentos recebidos',           'receita', 'fora_dre'),
    ('8.2',  'Aporte dos sócios',                                'receita', 'fora_dre'),
    ('8.3',  'Venda de imobilizado',                             'receita', 'fora_dre')
  ) AS plano (codigo, nome, natureza, dre);
  UPDATE categoria f SET pai_id = p.id
    FROM categoria p
   WHERE f.empresa_id = p_empresa AND p.empresa_id = p_empresa
     AND p.codigo = regexp_replace(f.codigo, '\.\d+$', '') AND f.codigo LIKE '%.%';
END $$;

CREATE FUNCTION app.ao_criar_empresa() RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public, app AS $$
BEGIN
  PERFORM app.criar_plano_padrao(NEW.id);
  INSERT INTO conta_bancaria (grupo_id, empresa_id, nome, tipo, data_saldo_inicial)
  VALUES (NEW.grupo_id, NEW.id, 'Caixa', 'caixa', (now() AT TIME ZONE 'America/Sao_Paulo')::date);
  RETURN NEW;
END $$;
CREATE TRIGGER empresa_padroes AFTER INSERT ON empresa FOR EACH ROW EXECUTE FUNCTION app.ao_criar_empresa();

-- Empresas que já existem recebem o plano padrão.
SELECT app.criar_plano_padrao(id) FROM empresa WHERE excluido_em IS NULL;
INSERT INTO conta_bancaria (grupo_id, empresa_id, nome, tipo, data_saldo_inicial)
  SELECT grupo_id, id, 'Caixa', 'caixa', (now() AT TIME ZONE 'America/Sao_Paulo')::date FROM empresa WHERE excluido_em IS NULL;
