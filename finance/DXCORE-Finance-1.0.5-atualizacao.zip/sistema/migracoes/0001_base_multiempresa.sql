-- DXCORE Finance · 0001 · Base multiempresa, usuários, sessões e auditoria
-- Princípios:
--  * Isolamento por GRUPO garantido pelo banco (Row Level Security), não só pelo código.
--  * Acesso por EMPRESA restrito às empresas vinculadas ao usuário.
--  * Nada é apagado fisicamente: exclusão lógica (excluido_em/excluido_por).
--  * Toda alteração vai para a tabela `auditoria`, que só aceita inserção.

CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE EXTENSION IF NOT EXISTS citext;

-- Papel do banco usado pela aplicação. NÃO é dono das tabelas, então o RLS vale para ele.
-- O usuário de login da aplicação é criado fora daqui (com senha secreta), membro deste papel:
--   CREATE ROLE dxcore_app_login LOGIN PASSWORD '...' IN ROLE dxcore_app;
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'dxcore_app') THEN
    CREATE ROLE dxcore_app NOLOGIN;
  END IF;
END $$;

CREATE SCHEMA IF NOT EXISTS app;   -- funções internas
GRANT USAGE ON SCHEMA app TO dxcore_app;
GRANT USAGE ON SCHEMA public TO dxcore_app;

-- ---------- Contexto da requisição ----------
CREATE FUNCTION app.grupo_atual() RETURNS uuid LANGUAGE sql STABLE AS
$$ SELECT nullif(current_setting('app.grupo_id', true), '')::uuid $$;

CREATE FUNCTION app.usuario_atual() RETURNS uuid LANGUAGE sql STABLE AS
$$ SELECT nullif(current_setting('app.usuario_id', true), '')::uuid $$;

CREATE FUNCTION app.empresas_permitidas() RETURNS uuid[] LANGUAGE sql STABLE AS
$$ SELECT coalesce(string_to_array(nullif(current_setting('app.empresas', true), ''), ',')::uuid[], '{}') $$;

-- ---------- Tabelas ----------
CREATE TABLE grupo (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  nome          text NOT NULL,
  criado_em     timestamptz NOT NULL DEFAULT now(),
  atualizado_em timestamptz NOT NULL DEFAULT now(),
  excluido_em   timestamptz,
  excluido_por  uuid
);

CREATE TABLE empresa (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  grupo_id       uuid NOT NULL REFERENCES grupo(id),
  cnpj           char(14) NOT NULL CHECK (cnpj ~ '^\d{14}$'),
  razao_social   text NOT NULL,
  nome_fantasia  text,
  criado_em      timestamptz NOT NULL DEFAULT now(),
  atualizado_em  timestamptz NOT NULL DEFAULT now(),
  excluido_em    timestamptz,
  excluido_por   uuid
);
CREATE UNIQUE INDEX empresa_cnpj_grupo ON empresa (grupo_id, cnpj) WHERE excluido_em IS NULL;

CREATE TABLE usuario (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  grupo_id       uuid NOT NULL REFERENCES grupo(id),
  nome           text NOT NULL,
  email          citext NOT NULL,
  senha_hash     text NOT NULL,
  ativo          boolean NOT NULL DEFAULT true,
  criado_em      timestamptz NOT NULL DEFAULT now(),
  atualizado_em  timestamptz NOT NULL DEFAULT now(),
  excluido_em    timestamptz,
  excluido_por   uuid
);
-- E-mail único no sistema inteiro (o login não sabe de antemão o grupo).
CREATE UNIQUE INDEX usuario_email ON usuario (email) WHERE excluido_em IS NULL;

CREATE TYPE papel AS ENUM ('administrador', 'financeiro', 'comercial', 'gerencia', 'contador');

CREATE TABLE vinculo (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  grupo_id       uuid NOT NULL REFERENCES grupo(id),
  usuario_id     uuid NOT NULL REFERENCES usuario(id),
  empresa_id     uuid NOT NULL REFERENCES empresa(id),
  papel          papel NOT NULL,
  criado_em      timestamptz NOT NULL DEFAULT now(),
  atualizado_em  timestamptz NOT NULL DEFAULT now(),
  excluido_em    timestamptz,
  excluido_por   uuid
);
CREATE UNIQUE INDEX vinculo_unico ON vinculo (usuario_id, empresa_id) WHERE excluido_em IS NULL;

-- Sessões e tentativas de login: SEM acesso direto da aplicação; só pelas funções abaixo.
CREATE TABLE sessao (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  usuario_id   uuid NOT NULL REFERENCES usuario(id),
  token_hash   bytea NOT NULL UNIQUE,
  criada_em    timestamptz NOT NULL DEFAULT now(),
  expira_em    timestamptz NOT NULL,
  revogada_em  timestamptz,
  ip           inet,
  agente       text
);

CREATE TABLE tentativa_login (
  id        bigserial PRIMARY KEY,
  email     citext NOT NULL,
  sucesso   boolean NOT NULL,
  ip        inet,
  em        timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX tentativa_login_email_em ON tentativa_login (email, em DESC);

CREATE TABLE auditoria (
  id           bigserial PRIMARY KEY,
  grupo_id     uuid,
  tabela       text NOT NULL,
  registro_id  uuid NOT NULL,
  acao         text NOT NULL CHECK (acao IN ('INCLUSAO', 'ALTERACAO', 'EXCLUSAO', 'RESTAURACAO')),
  antes        jsonb,
  depois       jsonb,
  usuario_id   uuid,
  em           timestamptz NOT NULL DEFAULT clock_timestamp()
);
CREATE INDEX auditoria_registro ON auditoria (tabela, registro_id, em);
CREATE INDEX auditoria_grupo_em ON auditoria (grupo_id, em DESC);

-- ---------- Gatilhos ----------
CREATE FUNCTION app.tocar_atualizado_em() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN NEW.atualizado_em := now(); RETURN NEW; END $$;

CREATE FUNCTION app.proibir_exclusao_fisica() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  RAISE EXCEPTION 'Exclusão física proibida em %. Use exclusão lógica (excluido_em).', TG_TABLE_NAME
    USING ERRCODE = 'insufficient_privilege';
END $$;

-- Grava auditoria. SECURITY DEFINER: grava mesmo sem a aplicação ter permissão na tabela.
CREATE FUNCTION app.auditar() RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public, app AS $$
DECLARE
  v_antes  jsonb := CASE WHEN TG_OP = 'UPDATE' THEN to_jsonb(OLD) - 'senha_hash' END;
  v_depois jsonb := to_jsonb(NEW) - 'senha_hash';
  v_acao   text;
BEGIN
  IF TG_OP = 'INSERT' THEN
    v_acao := 'INCLUSAO';
  ELSIF OLD.excluido_em IS NULL AND NEW.excluido_em IS NOT NULL THEN
    v_acao := 'EXCLUSAO';
  ELSIF OLD.excluido_em IS NOT NULL AND NEW.excluido_em IS NULL THEN
    v_acao := 'RESTAURACAO';
  ELSE
    v_acao := 'ALTERACAO';
    -- registra só os campos que mudaram (além do id)
    SELECT jsonb_object_agg(k, v_antes -> k), jsonb_object_agg(k, v_depois -> k)
      INTO v_antes, v_depois
      FROM jsonb_object_keys(v_depois) AS k
     WHERE k <> 'atualizado_em' AND (v_antes -> k) IS DISTINCT FROM (v_depois -> k);
    IF v_antes IS NULL THEN RETURN NEW; END IF; -- nada mudou de fato
  END IF;
  INSERT INTO auditoria (grupo_id, tabela, registro_id, acao, antes, depois, usuario_id)
  VALUES (coalesce((to_jsonb(NEW) ->> 'grupo_id')::uuid, NEW.id),
          TG_TABLE_NAME, NEW.id, v_acao, v_antes, v_depois, app.usuario_atual());
  RETURN NEW;
END $$;

CREATE FUNCTION app.auditoria_imutavel() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  RAISE EXCEPTION 'A trilha de auditoria não pode ser alterada nem apagada.' USING ERRCODE = 'insufficient_privilege';
END $$;
CREATE TRIGGER auditoria_imutavel BEFORE UPDATE OR DELETE OR TRUNCATE ON auditoria
  FOR EACH STATEMENT EXECUTE FUNCTION app.auditoria_imutavel();

DO $$
DECLARE t text;
BEGIN
  FOREACH t IN ARRAY ARRAY['grupo', 'empresa', 'usuario', 'vinculo'] LOOP
    EXECUTE format('CREATE TRIGGER %1$s_atualizado BEFORE UPDATE ON %1$I FOR EACH ROW EXECUTE FUNCTION app.tocar_atualizado_em()', t);
    EXECUTE format('CREATE TRIGGER %1$s_sem_delete BEFORE DELETE ON %1$I FOR EACH ROW EXECUTE FUNCTION app.proibir_exclusao_fisica()', t);
    EXECUTE format('CREATE TRIGGER %1$s_auditoria AFTER INSERT OR UPDATE ON %1$I FOR EACH ROW EXECUTE FUNCTION app.auditar()', t);
  END LOOP;
END $$;

-- ---------- Row Level Security ----------
ALTER TABLE grupo     ENABLE ROW LEVEL SECURITY;
ALTER TABLE empresa   ENABLE ROW LEVEL SECURITY;
ALTER TABLE usuario   ENABLE ROW LEVEL SECURITY;
ALTER TABLE vinculo   ENABLE ROW LEVEL SECURITY;
ALTER TABLE auditoria ENABLE ROW LEVEL SECURITY;

CREATE POLICY grupo_isolado ON grupo FOR ALL TO dxcore_app
  USING (id = app.grupo_atual()) WITH CHECK (id = app.grupo_atual());

-- Empresa: do grupo E entre as empresas a que o usuário tem vínculo.
CREATE POLICY empresa_isolada ON empresa FOR ALL TO dxcore_app
  USING (grupo_id = app.grupo_atual() AND id = ANY (app.empresas_permitidas()))
  WITH CHECK (grupo_id = app.grupo_atual());

CREATE POLICY usuario_isolado ON usuario FOR ALL TO dxcore_app
  USING (grupo_id = app.grupo_atual()) WITH CHECK (grupo_id = app.grupo_atual());

CREATE POLICY vinculo_isolado ON vinculo FOR ALL TO dxcore_app
  USING (grupo_id = app.grupo_atual()) WITH CHECK (grupo_id = app.grupo_atual());

CREATE POLICY auditoria_leitura ON auditoria FOR SELECT TO dxcore_app
  USING (grupo_id = app.grupo_atual());

GRANT SELECT, INSERT, UPDATE ON grupo, empresa, usuario, vinculo TO dxcore_app;
GRANT SELECT ON auditoria TO dxcore_app;
-- sessao e tentativa_login: nenhum GRANT direto.

-- ---------- Autenticação (funções controladas) ----------
-- Devolve dados para conferir a senha, ou nada se bloqueado por excesso de tentativas.
CREATE FUNCTION app.buscar_para_login(p_email text)
RETURNS TABLE (usuario_id uuid, grupo_id uuid, senha_hash text, bloqueado boolean)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public, app AS $$
  SELECT u.id, u.grupo_id, u.senha_hash,
         (SELECT count(*) FROM tentativa_login t
           WHERE t.email = p_email::citext AND NOT t.sucesso AND t.em > now() - interval '15 minutes') >= 5
    FROM usuario u
   WHERE u.email = p_email::citext AND u.ativo AND u.excluido_em IS NULL
$$;

CREATE FUNCTION app.registrar_tentativa(p_email text, p_sucesso boolean, p_ip inet)
RETURNS void LANGUAGE sql SECURITY DEFINER SET search_path = public, app AS $$
  INSERT INTO tentativa_login (email, sucesso, ip) VALUES (p_email::citext, p_sucesso, p_ip)
$$;

CREATE FUNCTION app.contar_falhas_recentes(p_email text) RETURNS bigint
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public, app AS $$
  SELECT count(*) FROM tentativa_login
   WHERE email = p_email::citext AND NOT sucesso AND em > now() - interval '15 minutes'
$$;

CREATE FUNCTION app.criar_sessao(p_usuario uuid, p_token_hash bytea, p_validade interval, p_ip inet, p_agente text)
RETURNS uuid LANGUAGE sql SECURITY DEFINER SET search_path = public, app AS $$
  INSERT INTO sessao (usuario_id, token_hash, expira_em, ip, agente)
  VALUES (p_usuario, p_token_hash, now() + p_validade, p_ip, p_agente)
  RETURNING id
$$;

-- Valida a sessão e devolve quem é o usuário e a que empresas ele tem acesso.
CREATE FUNCTION app.validar_sessao(p_token_hash bytea)
RETURNS TABLE (usuario_id uuid, grupo_id uuid, nome text, email text, empresas uuid[], papeis text[])
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public, app AS $$
  SELECT u.id, u.grupo_id, u.nome, u.email::text,
         coalesce(array_agg(v.empresa_id ORDER BY e.razao_social) FILTER (WHERE v.id IS NOT NULL), '{}'),
         coalesce(array_agg(v.papel::text ORDER BY e.razao_social) FILTER (WHERE v.id IS NOT NULL), '{}')
    FROM sessao s
    JOIN usuario u ON u.id = s.usuario_id AND u.ativo AND u.excluido_em IS NULL
    LEFT JOIN vinculo v ON v.usuario_id = u.id AND v.excluido_em IS NULL
    LEFT JOIN empresa e ON e.id = v.empresa_id AND e.excluido_em IS NULL
   WHERE s.token_hash = p_token_hash AND s.revogada_em IS NULL AND s.expira_em > now()
     AND (v.id IS NULL OR e.id IS NOT NULL)
   GROUP BY u.id
$$;

CREATE FUNCTION app.revogar_sessao(p_token_hash bytea) RETURNS void
LANGUAGE sql SECURITY DEFINER SET search_path = public, app AS $$
  UPDATE sessao SET revogada_em = now() WHERE token_hash = p_token_hash AND revogada_em IS NULL
$$;

REVOKE ALL ON ALL FUNCTIONS IN SCHEMA app FROM PUBLIC;
GRANT EXECUTE ON FUNCTION app.grupo_atual(), app.usuario_atual(), app.empresas_permitidas(),
  app.buscar_para_login(text), app.registrar_tentativa(text, boolean, inet), app.contar_falhas_recentes(text),
  app.criar_sessao(uuid, bytea, interval, inet, text), app.validar_sessao(bytea), app.revogar_sessao(bytea)
  TO dxcore_app;
