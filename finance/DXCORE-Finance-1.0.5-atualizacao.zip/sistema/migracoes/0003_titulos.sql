-- DXCORE Finance · 0003 · Contas a pagar e a receber
-- Título (o que se deve) → Parcela (quando vence) → Baixa (o que foi pago).

CREATE TYPE tipo_titulo AS ENUM ('pagar', 'receber');
CREATE TYPE origem_titulo AS ENUM ('manual', 'ofx', 'industrial', 'nfe', 'importacao');

CREATE TABLE titulo (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  grupo_id      uuid NOT NULL REFERENCES grupo(id),
  empresa_id    uuid NOT NULL REFERENCES empresa(id),
  tipo          tipo_titulo NOT NULL,
  pessoa_id     uuid REFERENCES pessoa(id),
  categoria_id  uuid NOT NULL REFERENCES categoria(id),
  descricao     text NOT NULL,
  documento     text,                 -- nº da NF, boleto, pedido…
  competencia   date NOT NULL,        -- mês a que pertence (DRE por competência)
  valor_total   bigint NOT NULL CHECK (valor_total > 0),   -- centavos
  origem        origem_titulo NOT NULL DEFAULT 'manual',
  observacoes   text,
  criado_por    uuid,
  criado_em     timestamptz NOT NULL DEFAULT now(),
  atualizado_em timestamptz NOT NULL DEFAULT now(),
  excluido_em   timestamptz,
  excluido_por  uuid
);
CREATE INDEX titulo_empresa_tipo ON titulo (empresa_id, tipo) WHERE excluido_em IS NULL;
CREATE INDEX titulo_pessoa ON titulo (pessoa_id) WHERE excluido_em IS NULL;

CREATE TABLE parcela (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  grupo_id      uuid NOT NULL REFERENCES grupo(id),
  empresa_id    uuid NOT NULL REFERENCES empresa(id),
  titulo_id     uuid NOT NULL REFERENCES titulo(id),
  numero        int NOT NULL CHECK (numero >= 1),
  vencimento    date NOT NULL,
  valor         bigint NOT NULL CHECK (valor > 0),
  criado_em     timestamptz NOT NULL DEFAULT now(),
  atualizado_em timestamptz NOT NULL DEFAULT now(),
  excluido_em   timestamptz,
  excluido_por  uuid
);
CREATE UNIQUE INDEX parcela_numero ON parcela (titulo_id, numero) WHERE excluido_em IS NULL;
CREATE INDEX parcela_vencimento ON parcela (empresa_id, vencimento) WHERE excluido_em IS NULL;

CREATE TABLE baixa (
  id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  grupo_id          uuid NOT NULL REFERENCES grupo(id),
  empresa_id        uuid NOT NULL REFERENCES empresa(id),
  parcela_id        uuid NOT NULL REFERENCES parcela(id),
  conta_bancaria_id uuid NOT NULL REFERENCES conta_bancaria(id),
  data_pagamento    date NOT NULL,
  valor_principal   bigint NOT NULL CHECK (valor_principal > 0),  -- quanto abate da parcela
  juros             bigint NOT NULL DEFAULT 0 CHECK (juros >= 0),
  multa             bigint NOT NULL DEFAULT 0 CHECK (multa >= 0),
  desconto          bigint NOT NULL DEFAULT 0 CHECK (desconto >= 0),
  -- valor que efetivamente entrou/saiu da conta
  valor_movimento   bigint GENERATED ALWAYS AS (valor_principal + juros + multa - desconto) STORED,
  observacao        text,
  criado_por        uuid,
  estornada_em      timestamptz,      -- baixa não se apaga: estorna
  estornada_por     uuid,
  motivo_estorno    text,
  criado_em         timestamptz NOT NULL DEFAULT now(),
  atualizado_em     timestamptz NOT NULL DEFAULT now(),
  CHECK (valor_principal + juros + multa - desconto >= 0)
);
CREATE INDEX baixa_parcela ON baixa (parcela_id) WHERE estornada_em IS NULL;
CREATE INDEX baixa_conta_data ON baixa (conta_bancaria_id, data_pagamento) WHERE estornada_em IS NULL;

CREATE TABLE titulo_rateio (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  grupo_id        uuid NOT NULL REFERENCES grupo(id),
  empresa_id      uuid NOT NULL REFERENCES empresa(id),
  titulo_id       uuid NOT NULL REFERENCES titulo(id),
  centro_custo_id uuid NOT NULL REFERENCES centro_custo(id),
  valor           bigint NOT NULL CHECK (valor > 0),
  criado_em       timestamptz NOT NULL DEFAULT now(),
  atualizado_em   timestamptz NOT NULL DEFAULT now(),
  excluido_em     timestamptz,
  excluido_por    uuid
);
CREATE INDEX titulo_rateio_titulo ON titulo_rateio (titulo_id) WHERE excluido_em IS NULL;

-- ---------- Integridade entre empresas ----------
-- Tudo que um título referencia precisa ser da MESMA empresa.
CREATE FUNCTION app.exigir_mesma_empresa(p_tabela text, p_id uuid, p_empresa uuid) RETURNS void
LANGUAGE plpgsql AS $$
DECLARE v uuid;
BEGIN
  IF p_id IS NULL THEN RETURN; END IF;
  EXECUTE format('SELECT empresa_id FROM %I WHERE id = $1', p_tabela) INTO v USING p_id;
  IF v IS DISTINCT FROM p_empresa THEN
    RAISE EXCEPTION 'Referência a % de outra empresa.', p_tabela USING ERRCODE = 'check_violation';
  END IF;
END $$;

CREATE FUNCTION app.validar_titulo() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE v_nat natureza;
BEGIN
  PERFORM app.exigir_mesma_empresa('pessoa', NEW.pessoa_id, NEW.empresa_id);
  PERFORM app.exigir_mesma_empresa('categoria', NEW.categoria_id, NEW.empresa_id);
  SELECT natureza INTO v_nat FROM categoria WHERE id = NEW.categoria_id;
  IF (NEW.tipo = 'pagar' AND v_nat <> 'despesa') OR (NEW.tipo = 'receber' AND v_nat <> 'receita') THEN
    RAISE EXCEPTION 'Categoria incompatível: conta a % exige categoria de %.', NEW.tipo,
      CASE NEW.tipo WHEN 'pagar' THEN 'despesa' ELSE 'receita' END USING ERRCODE = 'check_violation';
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER titulo_validar BEFORE INSERT OR UPDATE ON titulo FOR EACH ROW EXECUTE FUNCTION app.validar_titulo();

CREATE FUNCTION app.validar_parcela() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  PERFORM app.exigir_mesma_empresa('titulo', NEW.titulo_id, NEW.empresa_id);
  RETURN NEW;
END $$;
CREATE TRIGGER parcela_validar BEFORE INSERT OR UPDATE ON parcela FOR EACH ROW EXECUTE FUNCTION app.validar_parcela();

CREATE FUNCTION app.validar_rateio() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  PERFORM app.exigir_mesma_empresa('titulo', NEW.titulo_id, NEW.empresa_id);
  PERFORM app.exigir_mesma_empresa('centro_custo', NEW.centro_custo_id, NEW.empresa_id);
  RETURN NEW;
END $$;
CREATE TRIGGER rateio_validar BEFORE INSERT OR UPDATE ON titulo_rateio FOR EACH ROW EXECUTE FUNCTION app.validar_rateio();

-- Baixa: mesma empresa, e a soma das baixas nunca passa do valor da parcela.
-- Trava a parcela (FOR UPDATE) para que duas baixas simultâneas não ultrapassem o saldo.
CREATE FUNCTION app.validar_baixa() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE v_valor bigint; v_baixado bigint;
BEGIN
  PERFORM app.exigir_mesma_empresa('parcela', NEW.parcela_id, NEW.empresa_id);
  PERFORM app.exigir_mesma_empresa('conta_bancaria', NEW.conta_bancaria_id, NEW.empresa_id);
  IF TG_OP = 'UPDATE' THEN
    IF OLD.estornada_em IS NOT NULL THEN
      RAISE EXCEPTION 'Baixa estornada não pode ser alterada.' USING ERRCODE = 'check_violation';
    END IF;
    IF NEW.estornada_em IS NOT NULL THEN RETURN NEW; END IF;   -- estorno: sempre permitido
  END IF;
  SELECT valor INTO v_valor FROM parcela WHERE id = NEW.parcela_id AND excluido_em IS NULL FOR UPDATE;
  IF v_valor IS NULL THEN RAISE EXCEPTION 'Parcela inexistente ou excluída.' USING ERRCODE = 'check_violation'; END IF;
  SELECT coalesce(sum(valor_principal), 0) INTO v_baixado FROM baixa
   WHERE parcela_id = NEW.parcela_id AND estornada_em IS NULL AND id <> NEW.id;
  IF v_baixado + NEW.valor_principal > v_valor THEN
    RAISE EXCEPTION 'Baixa maior que o saldo da parcela (saldo: % centavos).', v_valor - v_baixado
      USING ERRCODE = 'check_violation';
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER baixa_validar BEFORE INSERT OR UPDATE ON baixa FOR EACH ROW EXECUTE FUNCTION app.validar_baixa();

-- Parcela/título com baixa ativa não pode ser excluído nem ter o valor alterado.
CREATE FUNCTION app.proteger_parcela_baixada() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF (NEW.valor IS DISTINCT FROM OLD.valor OR NEW.excluido_em IS NOT NULL AND OLD.excluido_em IS NULL)
     AND EXISTS (SELECT 1 FROM baixa WHERE parcela_id = OLD.id AND estornada_em IS NULL) THEN
    RAISE EXCEPTION 'Parcela com pagamento registrado: estorne a baixa antes.' USING ERRCODE = 'check_violation';
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER parcela_proteger BEFORE UPDATE ON parcela FOR EACH ROW EXECUTE FUNCTION app.proteger_parcela_baixada();

CREATE FUNCTION app.proteger_titulo_baixado() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF (NEW.valor_total IS DISTINCT FROM OLD.valor_total OR NEW.tipo IS DISTINCT FROM OLD.tipo
      OR NEW.excluido_em IS NOT NULL AND OLD.excluido_em IS NULL)
     AND EXISTS (SELECT 1 FROM baixa b JOIN parcela p ON p.id = b.parcela_id
                  WHERE p.titulo_id = OLD.id AND b.estornada_em IS NULL) THEN
    RAISE EXCEPTION 'Título com pagamento registrado: estorne as baixas antes.' USING ERRCODE = 'check_violation';
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER titulo_proteger BEFORE UPDATE ON titulo FOR EACH ROW EXECUTE FUNCTION app.proteger_titulo_baixado();

-- Auditoria (baixa tem estorno em vez de exclusão lógica: tratada como alteração)
DO $$
DECLARE t text;
BEGIN
  FOREACH t IN ARRAY ARRAY['titulo', 'parcela', 'baixa', 'titulo_rateio'] LOOP
    EXECUTE format('CREATE TRIGGER %1$s_atualizado BEFORE UPDATE ON %1$I FOR EACH ROW EXECUTE FUNCTION app.tocar_atualizado_em()', t);
    EXECUTE format('CREATE TRIGGER %1$s_sem_delete BEFORE DELETE ON %1$I FOR EACH ROW EXECUTE FUNCTION app.proibir_exclusao_fisica()', t);
    EXECUTE format('ALTER TABLE %I ENABLE ROW LEVEL SECURITY', t);
    EXECUTE format($p$CREATE POLICY %1$s_isolado ON %1$I FOR ALL TO dxcore_app
      USING (grupo_id = app.grupo_atual() AND empresa_id = ANY (app.empresas_permitidas()))
      WITH CHECK (grupo_id = app.grupo_atual() AND empresa_id = ANY (app.empresas_permitidas()))$p$, t);
    EXECUTE format('GRANT SELECT, INSERT, UPDATE ON %I TO dxcore_app', t);
  END LOOP;
END $$;
CREATE TRIGGER titulo_auditoria AFTER INSERT OR UPDATE ON titulo FOR EACH ROW EXECUTE FUNCTION app.auditar();
CREATE TRIGGER parcela_auditoria AFTER INSERT OR UPDATE ON parcela FOR EACH ROW EXECUTE FUNCTION app.auditar();
CREATE TRIGGER titulo_rateio_auditoria AFTER INSERT OR UPDATE ON titulo_rateio FOR EACH ROW EXECUTE FUNCTION app.auditar();
-- baixa não tem excluido_em: a função de auditoria usa to_jsonb, então tratamos à parte
CREATE FUNCTION app.auditar_baixa() RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public, app AS $$
BEGIN
  INSERT INTO auditoria (grupo_id, tabela, registro_id, acao, antes, depois, usuario_id)
  VALUES (NEW.grupo_id, 'baixa', NEW.id,
          CASE WHEN TG_OP = 'INSERT' THEN 'INCLUSAO' WHEN NEW.estornada_em IS NOT NULL AND OLD.estornada_em IS NULL THEN 'EXCLUSAO' ELSE 'ALTERACAO' END,
          CASE WHEN TG_OP = 'UPDATE' THEN to_jsonb(OLD) END, to_jsonb(NEW), app.usuario_atual());
  RETURN NEW;
END $$;
CREATE TRIGGER baixa_auditoria AFTER INSERT OR UPDATE ON baixa FOR EACH ROW EXECUTE FUNCTION app.auditar_baixa();

-- ---------- Situação de cada parcela (respeita o RLS de quem consulta) ----------
CREATE VIEW parcela_situacao WITH (security_invoker = true) AS
SELECT p.id, p.grupo_id, p.empresa_id, p.titulo_id, p.numero, p.vencimento, p.valor,
       t.tipo, t.pessoa_id, t.categoria_id, t.descricao, t.documento, t.competencia,
       (SELECT count(*) FROM parcela x WHERE x.titulo_id = p.titulo_id AND x.excluido_em IS NULL)::int AS total_parcelas,
       coalesce(b.baixado, 0)::bigint AS baixado,
       (p.valor - coalesce(b.baixado, 0))::bigint AS saldo,
       coalesce(b.movimentado, 0)::bigint AS movimentado,
       b.ultimo_pagamento
  FROM parcela p
  JOIN titulo t ON t.id = p.titulo_id AND t.excluido_em IS NULL
  LEFT JOIN LATERAL (
    SELECT sum(valor_principal) AS baixado, sum(valor_movimento) AS movimentado, max(data_pagamento) AS ultimo_pagamento
      FROM baixa WHERE parcela_id = p.id AND estornada_em IS NULL
  ) b ON true
 WHERE p.excluido_em IS NULL;
GRANT SELECT ON parcela_situacao TO dxcore_app;

-- Saldo atual de cada conta = saldo inicial + entradas − saídas (baixas a partir da data do saldo inicial).
CREATE VIEW conta_saldo WITH (security_invoker = true) AS
SELECT c.id, c.empresa_id, c.nome, c.tipo, c.ativo,
       c.saldo_inicial + coalesce(sum(CASE t.tipo WHEN 'receber' THEN b.valor_movimento ELSE -b.valor_movimento END), 0)::bigint AS saldo
  FROM conta_bancaria c
  LEFT JOIN baixa b ON b.conta_bancaria_id = c.id AND b.estornada_em IS NULL AND b.data_pagamento >= c.data_saldo_inicial
  LEFT JOIN parcela p ON p.id = b.parcela_id
  LEFT JOIN titulo t ON t.id = p.titulo_id
 WHERE c.excluido_em IS NULL
 GROUP BY c.id;
GRANT SELECT ON conta_saldo TO dxcore_app;
