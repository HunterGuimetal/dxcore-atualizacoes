// Restaura um backup .dxbak num banco VAZIO já com as migrações aplicadas (preparar-banco.mjs).
// Uso: DATABASE_URL_ADMIN=... node scripts/restaurar-dados.mjs ARQUIVO.dxbak
import { createReadStream } from "node:fs";
import { createGunzip } from "node:zlib";
import { createInterface } from "node:readline";
import postgres from "postgres";

const url = process.env.DATABASE_URL_ADMIN, origem = process.argv[2];
if (!url || !origem) { console.error("Uso: DATABASE_URL_ADMIN=... node scripts/restaurar-dados.mjs ARQUIVO"); process.exit(1); }
const sql = postgres(url, { max: 1, onnotice: () => {} });
const linhas = createInterface({ input: createReadStream(origem).pipe(createGunzip()), crlfDelay: Infinity })[Symbol.asyncIterator]();
const proxima = async () => { const r = await linhas.next(); return r.done ? null : r.value; };

try {
  const cab = JSON.parse((await proxima()) ?? "{}");
  if (cab.formato !== "dxcore-finance-backup") throw new Error("Arquivo não é um backup do DXCORE Finance.");
  const aplicadas = new Set((await sql`SELECT nome FROM _migracoes`).map((r) => r.nome));
  const faltando = cab.migracoes.filter((m) => !aplicadas.has(m));
  if (faltando.length) throw new Error(`O backup é de uma versão mais nova do sistema (${faltando.join(", ")}). Atualize o sistema antes de restaurar.`);
  const [{ n }] = await sql`SELECT count(*)::int n FROM grupo`;
  if (n > 0) throw new Error("O banco não está vazio. A restauração só é feita num banco novo.");

  let total = 0;
  await sql.begin(async (tx) => {
    // desliga gatilhos e chaves estrangeiras durante a carga (dados já são consistentes)
    await tx`SET LOCAL session_replication_role = replica`;
    // a migração 0002 cria nada sem empresas; limpa por garantia
    for (;;) {
      const l = await proxima();
      if (l === null) break;
      if (l.startsWith("@@TABELA ")) {
        const t = JSON.parse(l.slice(9));
        const cols = t.colunas.map((c) => `"${c}"`).join(", ");
        const w = await tx.unsafe(`COPY public."${t.nome}" (${cols}) FROM STDIN`).writable();
        for (;;) {
          const d = await proxima();
          if (d === null || d === "@@FIM") break;
          if (!w.write(d + "\n")) await new Promise((ok) => w.once("drain", ok));
          total++;
        }
        await new Promise((ok, erro) => { w.on("error", erro); w.end(ok); });
      } else if (l.startsWith("@@SEQUENCIAS ")) {
        for (const [nome, valor] of JSON.parse(l.slice(13))) await tx.unsafe(`SELECT setval('public."${nome}"', ${BigInt(valor)})`);
      }
    }
  });
  console.log(`✔ Restaurado: ${total} registros.`);
} catch (e) {
  console.error("✘ Restauração falhou:", e.message);
  process.exitCode = 1;
} finally {
  await sql.end();
}
