// Backup completo dos dados, sem depender do pg_dump (usado na instalação Windows).
// Formato: arquivo .dxbak (gzip) com um cabeçalho JSON por tabela + os dados em formato COPY.
// A estrutura do banco vem das migrações; o backup guarda quais já estavam aplicadas.
// Uso: DATABASE_URL_ADMIN=... node scripts/backup-dados.mjs ARQUIVO.dxbak
import { createWriteStream } from "node:fs";
import { pipeline } from "node:stream/promises";
import { PassThrough } from "node:stream";
import { createGzip } from "node:zlib";
import postgres from "postgres";

const url = process.env.DATABASE_URL_ADMIN, destino = process.argv[2];
if (!url || !destino) { console.error("Uso: DATABASE_URL_ADMIN=... node scripts/backup-dados.mjs ARQUIVO"); process.exit(1); }
const sql = postgres(url, { max: 1, onnotice: () => {} });
const saida = new PassThrough();
const gravando = pipeline(saida, createGzip({ level: 6 }), createWriteStream(destino));
gravando.catch(() => {}); // erro tratado abaixo (evita falha "não tratada")
const escrever = (t) => new Promise((ok) => (saida.write(t) ? ok() : saida.once("drain", ok)));

try {
  await sql`SET TRANSACTION ISOLATION LEVEL REPEATABLE READ`.catch(() => {});
  await sql.begin("ISOLATION LEVEL REPEATABLE READ READ ONLY", async (tx) => {
    const migracoes = (await tx`SELECT nome FROM _migracoes ORDER BY nome`).map((r) => r.nome);
    await escrever(JSON.stringify({ formato: "dxcore-finance-backup", versao: 1, criadoEm: new Date().toISOString(), migracoes }) + "\n");
    const tabelas = await tx`
      SELECT c.relname AS nome,
             array_agg(a.attname ORDER BY a.attnum) FILTER (WHERE a.attgenerated = '') AS colunas
        FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace
        JOIN pg_attribute a ON a.attrelid = c.oid AND a.attnum > 0 AND NOT a.attisdropped
       WHERE n.nspname = 'public' AND c.relkind = 'r' AND c.relname <> '_migracoes'
       GROUP BY c.relname ORDER BY c.relname`;
    for (const t of tabelas) {
      const cols = t.colunas.map((c) => `"${c}"`).join(", ");
      await escrever(`\n@@TABELA ${JSON.stringify({ nome: t.nome, colunas: t.colunas })}\n`);
      const stream = await tx.unsafe(`COPY public."${t.nome}" (${cols}) TO STDOUT`).readable();
      for await (const parte of stream) await escrever(parte);
      await escrever("@@FIM\n");
    }
    const seqs = await tx`SELECT sequencename AS nome, last_value AS valor FROM pg_sequences WHERE schemaname = 'public' AND last_value IS NOT NULL`;
    await escrever(`\n@@SEQUENCIAS ${JSON.stringify(seqs.map((s) => [s.nome, String(s.valor)]))}\n`);
  });
  saida.end();
  await gravando;
  console.log(`✔ Backup salvo: ${destino}`);
} catch (e) {
  console.error("✘ Backup falhou:", e.message);
  process.exitCode = 1;
  saida.destroy();
} finally {
  await sql.end();
}
