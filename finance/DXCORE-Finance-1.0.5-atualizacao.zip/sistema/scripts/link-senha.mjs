// Emergência: gera um link de nova senha para um usuário (ex.: o administrador esqueceu a senha).
// Uso no servidor:  bash deploy/link-senha.sh email@empresa.com.br
import { createHash, randomBytes } from "node:crypto";
import postgres from "postgres";

const [email] = process.argv.slice(2);
const url = process.env.DATABASE_URL_ADMIN, base = (process.env.APP_URL ?? "").replace(/\/$/, "");
if (!url || !email) { console.error("Uso: link-senha.mjs email (com DATABASE_URL_ADMIN e APP_URL)"); process.exit(1); }
const sql = postgres(url, { max: 1, onnotice: () => {} });
try {
  const [u] = await sql`SELECT id, nome FROM usuario WHERE email = ${email}::citext AND excluido_em IS NULL`;
  if (!u) { console.error("Usuário não encontrado."); process.exitCode = 1; }
  else {
    const token = randomBytes(32).toString("base64url");
    await sql.begin(async (tx) => {
      await tx`UPDATE usuario SET ativo = true WHERE id = ${u.id}`;
      await tx`UPDATE token_senha SET usado_em = now() WHERE usuario_id = ${u.id} AND usado_em IS NULL`;
      await tx`INSERT INTO token_senha (usuario_id, token_hash, tipo, expira_em) VALUES (${u.id}, ${createHash("sha256").update(token).digest()}, 'redefinicao', now() + interval '24 hours')`;
    });
    console.log(`\nLink de nova senha para ${u.nome} (vale 24 horas, uso único):\n\n  ${base || "https://SEU_DOMINIO"}/senha/${token}\n`);
  }
} finally { await sql.end(); }
