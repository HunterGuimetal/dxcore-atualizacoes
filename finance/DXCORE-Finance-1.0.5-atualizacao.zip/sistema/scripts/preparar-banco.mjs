// Cria o banco (se não existir), aplica as migrações e cria/atualiza o usuário restrito da aplicação.
// Usado pelo instalador Windows e pela atualização. Variáveis:
//   PG_ADMIN_URL   = postgres://dxcore:SENHA@127.0.0.1:PORTA/postgres   (superusuário)
//   SENHA_APP      = senha do usuário dxcore_app_login
import postgres from "postgres";
import { migrar } from "./migrar.mjs";

const admin = process.env.PG_ADMIN_URL, senhaApp = process.env.SENHA_APP;
if (!admin || !senhaApp) { console.error("Defina PG_ADMIN_URL e SENHA_APP."); process.exit(1); }
const BANCO = process.env.BANCO ?? "dxcore_finance";

const s = postgres(admin, { max: 1, onnotice: () => {} });
try {
  const [ja] = await s`SELECT 1 FROM pg_database WHERE datname = ${BANCO}`;
  if (!ja) { await s.unsafe(`CREATE DATABASE ${BANCO} ENCODING 'UTF8' TEMPLATE template0`); console.log("✔ Banco criado."); }
} finally { await s.end(); }

const urlBanco = admin.replace(/\/[^/?]+(\?|$)/, `/${BANCO}$1`);
await migrar(urlBanco);

const b = postgres(urlBanco, { max: 1, onnotice: () => {} });
try {
  const senha = senhaApp.replace(/'/g, "''");
  const [r] = await b`SELECT 1 FROM pg_roles WHERE rolname = 'dxcore_app_login'`;
  await b.unsafe(r ? `ALTER ROLE dxcore_app_login LOGIN PASSWORD '${senha}'` : `CREATE ROLE dxcore_app_login LOGIN PASSWORD '${senha}' IN ROLE dxcore_app`);
  const [g] = await b`SELECT count(*)::int n FROM grupo`;
  console.log(`✔ Banco pronto (${g.n} grupo(s) cadastrado(s)).`);
  if (process.argv.includes("--contar-grupos")) process.exitCode = g.n > 0 ? 10 : 0;
} finally { await b.end(); }
