#!/usr/bin/env bash
# Publica a atualização automática do DXCORE Finance no repositório dxcore-atualizacoes (pasta finance/),
# servido em https://dxcore.guimetal.com.br/finance/. Os computadores baixam sozinhos.
#
# Uso:  DXFIN_CHAVE=/caminho/dxcore-finance-chave-PRIVADA.pem bash scripts/publicar-atualizacao.sh [pasta-do-dxcore-atualizacoes]
# Antes: npm run build && bash scripts/empacotar-windows.sh   (e as notas da versão em novidades.json)
# A CHAVE PRIVADA nunca vai para nenhum repositório.
set -euo pipefail
cd "$(dirname "$0")/.."
VERSAO=$(node -p "require('./package.json').version")
ORIGEM=dist/DXCORE-Finance-Windows-$VERSAO
DESTINO=${1:-../dxcore-atualizacoes}/finance
CHAVE=${DXFIN_CHAVE:?Defina DXFIN_CHAVE com o caminho da chave PRIVADA}
[[ -d $ORIGEM/sistema ]] || { echo "Rode antes: npm run build && bash scripts/empacotar-windows.sh"; exit 1; }
node -e "const n=require('./novidades.json'); if(!n.some(x=>x.versao==='$VERSAO')){console.error('Escreva as notas da versão $VERSAO em novidades.json');process.exit(1)}"

mkdir -p "$DESTINO"
ARQ=DXCORE-Finance-$VERSAO-atualizacao.zip
rm -f "$DESTINO"/DXCORE-Finance-*-atualizacao.zip   # guarda só a versão atual (o computador guarda a anterior)
(cd "$ORIGEM" && zip -qr -9 "$OLDPWD/$DESTINO/$ARQ" sistema windows versao.txt)
SHA=$(sha256sum "$DESTINO/$ARQ" | cut -d' ' -f1)
TAM=$(stat -c %s "$DESTINO/$ARQ")
node -e "
const n=require('./novidades.json').find(x=>x.versao==='$VERSAO');
const m={produto:'DXCORE Finance',versao:'$VERSAO',data:n.data,arquivo:'$ARQ',sha256:'$SHA',tamanho:$TAM,notas:n.notas};
require('fs').writeFileSync('$DESTINO/versao.json', JSON.stringify(m,null,2)+'\n');"
openssl dgst -sha256 -sign "$CHAVE" -out "$DESTINO/versao.json.bin" "$DESTINO/versao.json"
base64 -w0 "$DESTINO/versao.json.bin" > "$DESTINO/versao.json.sig"; rm "$DESTINO/versao.json.bin"
# confere com a chave pública que vai instalada nos computadores
node -e "
const c=require('crypto'),fs=require('fs');
const x=fs.readFileSync('windows/chave-publica.xml','utf8');
const g=t=>Buffer.from(x.match(new RegExp('<'+t+'>([^<]+)</'+t+'>'))[1],'base64').toString('base64url');
const k=c.createPublicKey({key:{kty:'RSA',n:g('Modulus'),e:g('Exponent')},format:'jwk'});
const ok=c.verify('sha256',fs.readFileSync('$DESTINO/versao.json'),k,Buffer.from(fs.readFileSync('$DESTINO/versao.json.sig','utf8'),'base64'));
if(!ok){console.error('ASSINATURA NÃO CONFERE com windows/chave-publica.xml');process.exit(1)} console.log('✔ assinatura conferida');"
cat > "$DESTINO/LEIA-ME.txt" <<TXT
DXCORE Finance · atualizações automáticas
Os computadores com o DXCORE Finance instalado baixam daqui sozinhos.
O arquivo é assinado digitalmente: não edite à mão.
Versão atual: $VERSAO
TXT
printf '✔ Publicado em %s: versão %s (%s, %.1f MB)\n' "$DESTINO" "$VERSAO" "$ARQ" "$(echo "$TAM/1048576" | bc -l)"
