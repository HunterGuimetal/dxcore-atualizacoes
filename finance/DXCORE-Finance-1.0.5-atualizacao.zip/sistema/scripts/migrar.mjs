// Aplica as migrações SQL da pasta /migracoes, em ordem, uma única vez cada.
// Uso: DATABASE_URL_ADMIN=postgres://dono@host/banco node scripts/migrar.mjs
import { readdir, readFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import postgres from "postgres";

export async function migrar(url, { silencioso = false } = {}) {
  const sql = postgres(url, { max: 1, onnotice: () => {} });
  try {
    await sql`CREATE TABLE IF NOT EXISTS _migracoes (nome text PRIMARY KEY, aplicada_em timestamptz NOT NULL DEFAULT now())`;
    const feitas = new Set((await sql`SELECT nome FROM _migracoes`).map((r) => r.nome));
    // fileURLToPath: funciona no Windows e em pastas com espaço no nome
    const pasta = path.join(path.dirname(fileURLToPath(import.meta.url)), "..", "migracoes");
    const arquivos = (await readdir(pasta)).filter((a) => a.endsWith(".sql")).sort();
    for (const nome of arquivos) {
      if (feitas.has(nome)) continue;
      const conteudo = await readFile(path.join(pasta, nome), "utf8");
      await sql.begin(async (tx) => {
        await tx.unsafe(conteudo);
        await tx`INSERT INTO _migracoes (nome) VALUES (${nome})`;
      });
      if (!silencioso) console.log(`✔ ${nome}`);
    }
  } finally {
    await sql.end();
  }
}

if (process.argv[1] && import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href) {
  const url = process.env.DATABASE_URL_ADMIN;
  if (!url) {
    console.error("Defina DATABASE_URL_ADMIN (usuário dono do banco).");
    process.exit(1);
  }
  await migrar(url);
}
