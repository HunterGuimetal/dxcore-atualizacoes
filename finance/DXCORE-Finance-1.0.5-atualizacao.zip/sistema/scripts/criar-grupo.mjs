// Cria o grupo do cliente, as empresas e o primeiro usuário administrador.
// Pergunta tudo na tela (nada fica gravado em arquivo). Uso:
//   DATABASE_URL_ADMIN=postgres://... node scripts/criar-grupo.mjs
import { randomBytes, scryptSync } from "node:crypto";
import { createInterface } from "node:readline/promises";
import { stdin, stdout } from "node:process";
import postgres from "postgres";

const url = process.env.DATABASE_URL_ADMIN;
if (!url) { console.error("Defina DATABASE_URL_ADMIN."); process.exit(1); }

const rl = createInterface({ input: stdin, output: stdout, terminal: stdin.isTTY });
// lê linha a linha (guarda as linhas que chegarem antes da pergunta)
const linhas = rl[Symbol.asyncIterator]();
let silencio = false;
const escreverOriginal = rl._writeToOutput?.bind(rl);
if (escreverOriginal) rl._writeToOutput = (t) => { if (!silencio || t.includes("\n")) escreverOriginal(silencio ? "\n" : t); };
const lerLinha = async (q, oculto = false) => {
  stdout.write(q);
  silencio = oculto && stdin.isTTY;
  const { value, done } = await linhas.next();
  silencio = false;
  if (done) { console.error("\nEntrada encerrada."); process.exit(1); }
  return String(value).trim();
};
const perguntar = async (q, validar = (x) => x.length > 0) => {
  for (;;) { const r = await lerLinha(q); if (validar(r)) return r; console.log("  ↳ valor inválido, tente de novo."); }
};
const cnpjValido = (s) => {
  const d = s.replace(/\D/g, "");
  if (d.length !== 14 || /^(\d)\1{13}$/.test(d)) return false;
  const calc = (b, p) => { const r = p.reduce((a, x, i) => a + +b[i] * x, 0) % 11; return r < 2 ? 0 : 11 - r; };
  return calc(d, [5,4,3,2,9,8,7,6,5,4,3,2]) === +d[12] && calc(d, [6,5,4,3,2,9,8,7,6,5,4,3,2]) === +d[13];
};
const senhaOculta = (q) => lerLinha(q, true);

console.log("\n=== DXCORE Finance · cadastro do grupo de empresas ===\n");
const grupo = await perguntar("Nome do grupo (ex.: Grupo Guimetal): ");
const qtd = Number(await perguntar("Quantas empresas? ", (x) => /^[1-9]\d?$/.test(x)));
const empresas = [];
for (let i = 1; i <= qtd; i++) {
  console.log(`\nEmpresa ${i}:`);
  const cnpj = (await perguntar("  CNPJ: ", cnpjValido)).replace(/\D/g, "");
  const razao = await perguntar("  Razão social: ", (x) => x.length >= 3);
  const fantasia = await perguntar("  Nome fantasia (Enter para pular): ", () => true);
  empresas.push({ cnpj, razao, fantasia: fantasia || null });
}
console.log("\nAdministrador (primeiro usuário):");
const nome = await perguntar("  Nome: ");
const email = (await perguntar("  E-mail: ", (x) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(x))).toLowerCase();
let senha;
for (;;) {
  senha = await senhaOculta("  Senha (mín. 10 caracteres, letras e números): ");
  if (senha.length >= 10 && /[A-Za-z]/.test(senha) && /\d/.test(senha) && (await senhaOculta("  Repita a senha: ")) === senha) break;
  console.log("  ↳ senha fraca ou diferente, tente de novo.");
}

const N = 2 ** 15, r = 8, p = 1, sal = randomBytes(16);
const hash = scryptSync(senha.normalize("NFKC"), sal, 32, { N, r, p, maxmem: 128 * N * r * 2 });
const senhaHash = ["scrypt", N, r, p, sal.toString("base64"), hash.toString("base64")].join("$");

const sql = postgres(url, { max: 1, onnotice: () => {} });
try {
  await sql.begin(async (tx) => {
    const [g] = await tx`INSERT INTO grupo (nome) VALUES (${grupo}) RETURNING id`;
    const [u] = await tx`INSERT INTO usuario (grupo_id, nome, email, senha_hash) VALUES (${g.id}, ${nome}, ${email}, ${senhaHash}) RETURNING id`;
    for (const e of empresas) {
      const [x] = await tx`INSERT INTO empresa (grupo_id, cnpj, razao_social, nome_fantasia) VALUES (${g.id}, ${e.cnpj}, ${e.razao}, ${e.fantasia}) RETURNING id`;
      await tx`INSERT INTO vinculo (grupo_id, usuario_id, empresa_id, papel) VALUES (${g.id}, ${u.id}, ${x.id}, 'administrador')`;
    }
  });
  console.log(`\n✔ Pronto! ${qtd} empresa(s) cadastrada(s). Entre no sistema com ${email}.\n`);
} catch (e) {
  console.error("\n✘ Não foi possível cadastrar:", e.message);
  process.exitCode = 1;
} finally {
  await sql.end();
  process.exit();
}
