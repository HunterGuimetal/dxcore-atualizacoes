-- Texto padronizado: CAIXA ALTA, sem acentos e sem espaços duplicados, em tudo o que é digitado,
-- importado (extrato OFX) ou exportado. Pedido da empresa (padrão único para o contador e para buscas).
-- Fica no banco para valer em qualquer caminho de entrada. E-mails, senhas e nomes de usuário não mudam.

CREATE FUNCTION app.padronizar(t text) RETURNS text LANGUAGE sql IMMUTABLE PARALLEL SAFE AS
$$ SELECT CASE WHEN t IS NULL THEN NULL
               ELSE btrim(regexp_replace(upper(public.unaccent('public.unaccent'::regdictionary, t)), '\s+', ' ', 'g')) END $$;

DO $$
DECLARE
  alvo record;
  atribs text;
BEGIN
  FOR alvo IN SELECT * FROM (VALUES
      ('grupo',              ARRAY['nome']),
      ('empresa',            ARRAY['razao_social','nome_fantasia']),
      ('pessoa',             ARRAY['nome','nome_fantasia','cidade','observacoes']),
      ('conta_bancaria',     ARRAY['nome']),
      ('categoria',          ARRAY['nome']),
      ('centro_custo',       ARRAY['nome']),
      ('titulo',             ARRAY['descricao','documento','observacoes']),
      ('baixa',              ARRAY['observacao','motivo_estorno']),
      ('movimento_bancario', ARRAY['descricao','documento'])
    ) AS v(tabela, colunas)
  LOOP
    SELECT string_agg(format('NEW.%1$I := app.padronizar(NEW.%1$I);', c), ' ') INTO atribs FROM unnest(alvo.colunas) c;
    EXECUTE format('CREATE FUNCTION app.padronizar_%1$s() RETURNS trigger LANGUAGE plpgsql AS $f$ BEGIN %2$s RETURN NEW; END $f$', alvo.tabela, atribs);
    -- nome começa com "a_" para rodar antes das outras validações (gatilhos BEFORE rodam em ordem alfabética)
    EXECUTE format('CREATE TRIGGER a_padronizar BEFORE INSERT OR UPDATE ON %1$I FOR EACH ROW EXECUTE FUNCTION app.padronizar_%1$s()', alvo.tabela);
    -- dados que já existem: converte uma vez, sem disparar as proteções (lançamento pago, auditoria) — é só formato
    EXECUTE format('ALTER TABLE %I DISABLE TRIGGER USER', alvo.tabela);
    EXECUTE format('UPDATE %I SET %s', alvo.tabela,
      (SELECT string_agg(format('%1$I = app.padronizar(%1$I)', c), ', ') FROM unnest(alvo.colunas) c));
    EXECUTE format('ALTER TABLE %I ENABLE TRIGGER USER', alvo.tabela);
  END LOOP;
END $$;

-- regras aprendidas na conciliação guardam a "chave" já em caixa alta sem acento (motor.normalizar): nada a mudar.
