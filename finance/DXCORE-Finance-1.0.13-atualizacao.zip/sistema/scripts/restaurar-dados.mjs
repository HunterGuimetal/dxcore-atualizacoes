// Restaura um backup .dxbak num banco VAZIO já com as migrações aplicadas (preparar-banco.mjs).
// Aceita o formato 2 (JSON por registro, atual) e o formato 1 (COPY, versões até 1.0.10).
// Uso: DATABASE_URL_ADMIN=... node scripts/restaurar-dados.mjs ARQUIVO.dxbak
import { readFileSync } from "node:fs";
import { gunzipSync } from "node:zlib";
import postgres from "postgres";

const url = process.env.DATABASE_URL_ADMIN, origem = process.argv[2];
if (!url || !origem) { console.error("Uso: DATABASE_URL_ADMIN=... node scripts/restaurar-dados.mjs ARQUIVO"); process.exit(1); }
// mesmas tabelas/colunas da migração 0006_texto_padronizado.sql
const TEXTO_PADRONIZADO = [
  ["grupo", ["nome"]], ["empresa", ["razao_social", "nome_fantasia"]], ["pessoa", ["nome", "nome_fantasia", "cidade", "observacoes"]],
  ["conta_bancaria", ["nome"]], ["categoria", ["nome"]], ["centro_custo", ["nome"]], ["titulo", ["descricao", "documento", "observacoes"]],
  ["baixa", ["observacao", "motivo_estorno"]], ["movimento_bancario", ["descricao", "documento"]],
];
const relogio = setTimeout(() => { console.error("✘ Restauração falhou: demorou mais de 10 minutos."); process.exit(1); }, 10 * 60_000);
relogio.unref();
const sql = postgres(url, { max: 1, onnotice: () => {} });

try {
  let texto;
  try { texto = gunzipSync(readFileSync(origem)).toString("utf8"); }
  catch { throw new Error("O arquivo de backup está incompleto ou danificado. Gere um backup novo."); }
  const linhas = texto.split("\n");
  if (linhas.at(-1) === "") linhas.pop();
  const cab = JSON.parse(linhas[0] ?? "{}");
  if (cab.formato !== "dxcore-finance-backup") throw new Error("Arquivo não é um backup do DXCORE Finance.");
  if (!linhas.some((l) => l.startsWith("@@SEQUENCIAS "))) throw new Error("O arquivo de backup está incompleto (gerado por um backup que travou). Gere um backup novo.");
  const aplicadas = new Set((await sql`SELECT nome FROM _migracoes`).map((r) => r.nome));
  const faltando = cab.migracoes.filter((m) => !aplicadas.has(m));
  if (faltando.length) throw new Error(`O backup é de uma versão mais nova do sistema (${faltando.join(", ")}). Atualize o sistema antes de restaurar.`);
  const [{ n }] = await sql`SELECT count(*)::int n FROM grupo`;
  if (n > 0) throw new Error("O banco não está vazio. A restauração só é feita num banco novo.");

  let total = 0;
  await sql.begin(async (tx) => {
    // desliga gatilhos e chaves estrangeiras durante a carga (dados já são consistentes)
    await tx`SET LOCAL session_replication_role = replica`;
    for (let i = 1; i < linhas.length; i++) {
      const l = linhas[i];
      if (l.startsWith("@@TABELA ")) {
        const t = JSON.parse(l.slice(9));
        const cols = t.colunas.map((c) => `"${c}"`).join(", ");
        const dados = [];
        for (i++; i < linhas.length && linhas[i] !== "@@FIM"; i++) dados.push(linhas[i]);
        if (cab.versao === 1) {
          // formato antigo: texto do COPY, uma linha por registro
          if (dados.length) {
            const w = await tx.unsafe(`COPY public."${t.nome}" (${cols}) FROM STDIN`).writable();
            await new Promise((ok, erro) => { w.on("error", erro); w.end(dados.join("\n") + "\n", ok); });
          }
        } else {
          for (let k = 0; k < dados.length; k += 500) {
            const lote = "[" + dados.slice(k, k + 500).join(",") + "]";
            await tx.unsafe(`INSERT INTO public."${t.nome}" (${cols}) SELECT ${cols} FROM json_populate_recordset(NULL::public."${t.nome}", $1::text::json)`, [lote]);
          }
        }
        total += dados.length;
      } else if (l.startsWith("@@SEQUENCIAS ")) {
        for (const [nome, valor] of JSON.parse(l.slice(13))) await tx.unsafe(`SELECT setval('public."${nome}"', ${BigInt(valor)})`);
      }
    }
    // backup de versão anterior à 0006: converte os textos para o padrão (CAIXA ALTA, sem acentos)
    if (!cab.migracoes.includes("0006_texto_padronizado.sql") && aplicadas.has("0006_texto_padronizado.sql")) {
      for (const [tabela, colunas] of TEXTO_PADRONIZADO) {
        await tx.unsafe(`UPDATE public."${tabela}" SET ${colunas.map((c) => `"${c}" = app.padronizar("${c}")`).join(", ")}`);
      }
      console.log("✔ Textos convertidos para o padrão da versão atual.");
    }
  });
  console.log(`✔ Restaurado: ${total} registros.`);
} catch (e) {
  console.error("✘ Restauração falhou:", e.message);
  process.exitCode = 1;
} finally {
  await sql.end({ timeout: 5 });
  clearTimeout(relogio);
}
