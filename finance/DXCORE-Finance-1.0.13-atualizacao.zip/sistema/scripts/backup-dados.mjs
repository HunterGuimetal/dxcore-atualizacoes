// Backup completo dos dados, sem depender do pg_dump (usado na instalação Windows).
// Formato 2: arquivo .dxbak (gzip) com um cabeçalho JSON e, por tabela, uma linha JSON por registro.
// Usa só consultas comuns (SELECT) e grava o arquivo de uma vez: o modo COPY em fluxo travava no Windows.
// A estrutura do banco vem das migrações; o backup guarda quais já estavam aplicadas.
// Uso: DATABASE_URL_ADMIN=... node scripts/backup-dados.mjs ARQUIVO.dxbak
import { writeFileSync, renameSync } from "node:fs";
import { gzipSync } from "node:zlib";
import postgres from "postgres";

const url = process.env.DATABASE_URL_ADMIN, destino = process.argv[2];
if (!url || !destino) { console.error("Uso: DATABASE_URL_ADMIN=... node scripts/backup-dados.mjs ARQUIVO"); process.exit(1); }
// nunca fica preso para sempre
const relogio = setTimeout(() => { console.error("✘ Backup falhou: demorou mais de 10 minutos."); process.exit(1); }, 10 * 60_000);
relogio.unref();
const sql = postgres(url, { max: 1, onnotice: () => {} });
const progresso = (m) => { if (process.env.DX_PROGRESSO) console.log(m); };

try {
  const partes = [];
  await sql.begin("ISOLATION LEVEL REPEATABLE READ READ ONLY", async (tx) => {
    const migracoes = (await tx`SELECT nome FROM _migracoes ORDER BY nome`).map((r) => r.nome);
    partes.push(JSON.stringify({ formato: "dxcore-finance-backup", versao: 2, criadoEm: new Date().toISOString(), migracoes }));
    const tabelas = await tx`
      SELECT c.relname AS nome,
             array_agg(a.attname ORDER BY a.attnum) FILTER (WHERE a.attgenerated = '') AS colunas
        FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace
        JOIN pg_attribute a ON a.attrelid = c.oid AND a.attnum > 0 AND NOT a.attisdropped
       WHERE n.nspname = 'public' AND c.relkind = 'r' AND c.relname <> '_migracoes'
       GROUP BY c.relname ORDER BY c.relname`;
    for (const t of tabelas) {
      const cols = t.colunas.map((c) => `"${c}"`).join(", ");
      const linhas = await tx.unsafe(`SELECT row_to_json(x)::text AS j FROM (SELECT ${cols} FROM public."${t.nome}") x`);
      partes.push(`@@TABELA ${JSON.stringify({ nome: t.nome, colunas: t.colunas })}`);
      for (const l of linhas) partes.push(l.j);
      partes.push("@@FIM");
      progresso(`  · ${t.nome}: ${linhas.length} registros`);
    }
    const seqs = await tx`SELECT sequencename AS nome, last_value AS valor FROM pg_sequences WHERE schemaname = 'public' AND last_value IS NOT NULL`;
    partes.push(`@@SEQUENCIAS ${JSON.stringify(seqs.map((s) => [s.nome, String(s.valor)]))}`);
  });
  // grava num temporário e renomeia: nunca fica um arquivo pela metade com o nome final
  const tmp = destino + ".parcial";
  writeFileSync(tmp, gzipSync(Buffer.from(partes.join("\n") + "\n", "utf8"), { level: 6 }));
  renameSync(tmp, destino);
  console.log(`✔ Backup salvo: ${destino}`);
} catch (e) {
  console.error("✘ Backup falhou:", e.message);
  process.exitCode = 1;
} finally {
  await sql.end({ timeout: 5 });
  clearTimeout(relogio);
}
