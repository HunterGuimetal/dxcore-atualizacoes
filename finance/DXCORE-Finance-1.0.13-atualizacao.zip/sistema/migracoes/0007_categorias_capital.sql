-- Categorias de entrada de capital (pedido da empresa): dinheiro que entra mas NÃO é venda nem serviço.
-- Ficam fora da DRE (não mexem no lucro), mas aparecem no fluxo de caixa e na conciliação.
-- Vale para as empresas já cadastradas e para as novas. Não altera categorias que o usuário renomeou.

CREATE FUNCTION app.complementar_plano(p_empresa uuid) RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public, app AS $$
DECLARE v_grupo uuid;
BEGIN
  SELECT grupo_id INTO v_grupo FROM empresa WHERE id = p_empresa;
  -- nomes novos só onde ainda está o nome padrão antigo
  UPDATE categoria SET nome = 'Entradas de capital e recursos financeiros'
   WHERE empresa_id = p_empresa AND codigo = '8' AND excluido_em IS NULL AND app.padronizar(nome) = 'ENTRADAS FORA DA DRE';
  UPDATE categoria SET nome = 'Empréstimos de terceiros (bancos e financiamentos)'
   WHERE empresa_id = p_empresa AND codigo = '8.1' AND excluido_em IS NULL AND app.padronizar(nome) = 'EMPRESTIMOS E FINANCIAMENTOS RECEBIDOS';

  INSERT INTO categoria (grupo_id, empresa_id, codigo, nome, natureza, grupo_dre, pai_id)
  SELECT v_grupo, p_empresa, n.codigo, n.nome, n.natureza::natureza, 'fora_dre'::grupo_dre,
         (SELECT p.id FROM categoria p WHERE p.empresa_id = p_empresa AND p.codigo = n.pai AND p.excluido_em IS NULL)
    FROM (VALUES
      ('8.4', 'Integralização de capital social',                      'receita', '8'),
      ('8.5', 'Empréstimos de sócios',                                 'receita', '8'),
      ('8.6', 'Adiantamento para futuro aumento de capital (AFAC)',    'receita', '8'),
      ('7.4', 'Devolução de empréstimos de sócios',                    'despesa', '7')
    ) AS n (codigo, nome, natureza, pai)
   WHERE EXISTS (SELECT 1 FROM categoria p WHERE p.empresa_id = p_empresa AND p.codigo = n.pai AND p.excluido_em IS NULL)
     AND NOT EXISTS (SELECT 1 FROM categoria c WHERE c.empresa_id = p_empresa AND c.codigo = n.codigo AND c.excluido_em IS NULL);
END $$;

-- empresas novas: plano padrão + complemento
CREATE OR REPLACE FUNCTION app.ao_criar_empresa() RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public, app AS $$
BEGIN
  PERFORM app.criar_plano_padrao(NEW.id);
  PERFORM app.complementar_plano(NEW.id);
  INSERT INTO conta_bancaria (grupo_id, empresa_id, nome, tipo, data_saldo_inicial)
  VALUES (NEW.grupo_id, NEW.id, 'Caixa', 'caixa', (now() AT TIME ZONE 'America/Sao_Paulo')::date);
  RETURN NEW;
END $$;

-- empresas que já existem
SELECT app.complementar_plano(id) FROM empresa WHERE excluido_em IS NULL;
