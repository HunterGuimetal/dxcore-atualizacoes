﻿# DXCORE Finance - abre o sistema (liga o servidor se ainda não estiver no ar)
. (Join-Path $PSScriptRoot 'comum.ps1')
. (Join-Path $PSScriptRoot 'atualizacao.ps1')
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

# Igual ao Industrial: ao abrir, confere se há versão nova. Se houver, avisa, espera atualizar e só então abre.
function AtualizarAoAbrir($c) {
  $m = ProcurarAtualizacao
  if (-not $m) { return }
  $f = New-Object System.Windows.Forms.Form
  $f.Text = 'DXCORE Finance'; $f.Width = 460; $f.Height = 150; $f.StartPosition = 'CenterScreen'
  $f.FormBorderStyle = 'FixedDialog'; $f.ControlBox = $false; $f.TopMost = $true
  $l = New-Object System.Windows.Forms.Label
  $l.Text = "Atualizando o DXCORE Finance para a versão $($m.versao)...`r`nAguarde, leva cerca de 1 minuto."
  $l.AutoSize = $false; $l.Dock = 'Fill'; $l.TextAlign = 'MiddleCenter'; $l.Font = New-Object System.Drawing.Font('Segoe UI', 11)
  $f.Controls.Add($l); $f.Show(); [System.Windows.Forms.Application]::DoEvents()
  try {
    if (SistemaResponde $c) { New-Item -ItemType File -Path $DXPedidoBusca -Force | Out-Null }
    else { Start-Process -FilePath (Join-Path $env:WINDIR 'System32\wscript.exe') -ArgumentList ('"' + (Join-Path $PSScriptRoot 'iniciar.vbs') + '"') }
    # espera a versão nova estar instalada e o sistema responder (até 5 min)
    $fim = (Get-Date).AddMinutes(5)
    while ((Get-Date) -lt $fim) {
      for ($i = 0; $i -lt 10; $i++) { Start-Sleep -Milliseconds 200; [System.Windows.Forms.Application]::DoEvents() }
      if ((VersaoInstalada) -eq $m.versao -and (SistemaResponde $c)) { break }
    }
  } finally { $f.Close() }
}
try {
  $c = LerConfig
  try { AtualizarAoAbrir $c } catch { Log ('abrir: verificação de atualização falhou: ' + $_.Exception.Message) }
  if (-not (SistemaResponde $c)) {
    Start-Process -FilePath (Join-Path $env:WINDIR 'System32\wscript.exe') -ArgumentList ('"' + (Join-Path $PSScriptRoot 'iniciar.vbs') + '"')
    $ok = $false
    for ($i = 0; $i -lt 60; $i++) { Start-Sleep -Milliseconds 750; if (SistemaResponde $c) { $ok = $true; break } }
    if (-not $ok) { throw "O DXCORE Finance não respondeu. Veja os registros em $DXLog" }
  }
  $url = "http://localhost:$($c.porta)/"
  $nav = Navegador
  if ($nav) { Start-Process -FilePath $nav -ArgumentList "--app=$url" } else { Start-Process $url }
} catch {
  Log ('abrir: ' + $_.Exception.Message)
  [System.Windows.Forms.MessageBox]::Show($_.Exception.Message, 'DXCORE Finance', 'OK', 'Error') | Out-Null
}
