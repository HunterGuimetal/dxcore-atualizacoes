﻿# DXCORE Finance - instalar ESTAÇÃO: o aplicativo neste PC, usando os dados do PC PRINCIPAL.
# Não instala banco de dados aqui: tudo o que for lançado fica no PC principal e todos veem o mesmo.
# Não precisa atualizar: quando o PC principal atualiza, as estações já abrem a versão nova.
$ErrorActionPreference = 'Stop'
$Host.UI.RawUI.WindowTitle = 'DXCORE Finance - instalar estação'
Add-Type -AssemblyName System.Windows.Forms
$porta = 47820
$pasta = Join-Path $env:LOCALAPPDATA 'DXCORE-Finance-Estacao'

function Responde([string]$endereco) {
  try {
    $r = Invoke-WebRequest -UseBasicParsing -TimeoutSec 4 -Uri "http://${endereco}:$porta/"
    return ($r.StatusCode -eq 200 -and $r.Content -match 'DXCORE')
  } catch { return $false }
}

# Procura na rede local um PC com o DXCORE Finance no ar (porta 47820), em paralelo, ~2 segundos.
function ProcurarPrincipal {
  $ips = @(Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue |
    Where-Object { $_.IPAddress -notmatch '^(127\.|169\.254\.)' -and $_.PrefixOrigin -ne 'WellKnown' } | Select-Object -ExpandProperty IPAddress)
  $achados = @()
  foreach ($ip in $ips) {
    $base = ($ip -split '\.')[0..2] -join '.'
    $tentativas = foreach ($n in 1..254) {
      $alvo = "$base.$n"; $cli = New-Object Net.Sockets.TcpClient
      [pscustomobject]@{ ip = $alvo; cli = $cli; t = $cli.ConnectAsync($alvo, $porta) }
    }
    Start-Sleep -Milliseconds 1500
    foreach ($x in $tentativas) {
      if ($x.t.Status -eq 'RanToCompletion' -and $x.cli.Connected) { $achados += $x.ip }
      try { $x.cli.Close() } catch {}
    }
  }
  return @($achados | Where-Object { Responde $_ } | Select-Object -Unique)
}

function Navegador {
  foreach ($k in @('HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\msedge.exe', 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\msedge.exe',
                   'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe', 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe')) {
    try { $v = (Get-ItemProperty -Path $k -ErrorAction Stop).'(default)'; if ($v -and (Test-Path $v)) { return $v } } catch {}
  }
  $c = @("${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe", "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe",
         "$env:ProgramFiles\Google\Chrome\Application\chrome.exe", "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe")
  return ($c | Where-Object { $_ -and (Test-Path $_) } | Select-Object -First 1)
}

try {
  Write-Host ''
  Write-Host '  DXCORE Finance - instalar ESTAÇÃO' -ForegroundColor Cyan
  Write-Host '  O aplicativo fica neste PC, mas os dados ficam no PC PRINCIPAL (todos veem o mesmo).'
  Write-Host ''

  # Este PC já tem o DXCORE completo (com dados próprios)? Precisa desinstalar antes.
  if (Test-Path (Join-Path $env:LOCALAPPDATA 'DXCORE-Finance\config.json')) {
    Write-Host 'Este PC tem o DXCORE Finance COMPLETO instalado, com dados próprios (separados dos outros PCs).' -ForegroundColor Yellow
    Write-Host 'Para virar estação:'
    Write-Host '  1. Confira se ninguém lançou nada importante NESTE PC (o que estiver aqui não vai para o principal).'
    Write-Host '  2. Rode o DESINSTALAR.bat deste PC (ele faz um backup antes).'
    Write-Host '  3. Rode este INSTALAR-ESTACAO.bat de novo.'
    Write-Host ''
    Write-Host 'Se ESTE for o PC principal (onde os dados ficam), não instale estação nele.' -ForegroundColor Yellow
    exit 1
  }

  Write-Host '-> Procurando o PC principal na rede...'
  $achados = @(ProcurarPrincipal)
  $endereco = $null
  if ($achados.Count -eq 1) {
    Write-Host "   Encontrado: $($achados[0])" -ForegroundColor Green
    $endereco = $achados[0]
  } elseif ($achados.Count -gt 1) {
    Write-Host '   Encontrei mais de um:'; for ($i = 0; $i -lt $achados.Count; $i++) { Write-Host "   $($i + 1)) $($achados[$i])" }
    $n = Read-Host '   Digite o número do PC principal'
    $endereco = $achados[[int]$n - 1]
  } else {
    Write-Host '   Não encontrei automaticamente.' -ForegroundColor Yellow
    Write-Host '   No PC principal, abra o arquivo "DXCORE Finance - acesso.txt" (Área de Trabalho) e veja o endereço.'
    $digitado = Read-Host '   Digite o endereço do PC principal (ex.: 192.168.0.25)'
    $endereco = ($digitado -replace '^https?://', '' -replace ':\d+.*$', '' -replace '/.*$', '').Trim()
    if (-not (Responde $endereco)) {
      throw "O PC principal ($endereco) não respondeu. Confira: o PC principal está ligado, os dois PCs estão na mesma rede, e a rede do Windows do PC principal está como 'Privada'."
    }
  }

  $url = "http://${endereco}:$porta/"
  New-Item -ItemType Directory -Path $pasta -Force | Out-Null
  Copy-Item (Join-Path $PSScriptRoot 'DXCORE-Finance.ico') $pasta -Force
  @{ principal = $endereco; url = $url; instaladoEm = (Get-Date -Format s) } | ConvertTo-Json | Set-Content (Join-Path $pasta 'estacao.json') -Encoding UTF8

  # atalho: abre numa janela própria, sem barra de navegador (igual aplicativo)
  $nav = Navegador
  $ws = New-Object -ComObject WScript.Shell
  $menu = Join-Path ([Environment]::GetFolderPath('StartMenu')) 'Programs'
  foreach ($arq in @((Join-Path ([Environment]::GetFolderPath('Desktop')) 'DXCORE Finance.lnk'), (Join-Path $menu 'DXCORE Finance.lnk'))) {
    $s = $ws.CreateShortcut($arq)
    if ($nav) { $s.TargetPath = $nav; $s.Arguments = "--app=$url" } else { $s.TargetPath = $url }
    $s.IconLocation = (Join-Path $pasta 'DXCORE-Finance.ico') + ',0'
    $s.Description = 'DXCORE Finance (dados no PC principal)'
    $s.Save()
  }
  Write-Host ''
  Write-Host '  =====================================' -ForegroundColor Green
  Write-Host '   Estação instalada!' -ForegroundColor Green
  Write-Host "   Usa os dados do PC principal: $endereco" -ForegroundColor Green
  Write-Host '   Abra pelo ícone "DXCORE Finance" na Área de Trabalho.' -ForegroundColor Green
  Write-Host '  =====================================' -ForegroundColor Green
  Write-Host '  Lembrete: o PC principal precisa estar ligado e na mesma rede.'
  if ($nav) { Start-Process -FilePath $nav -ArgumentList "--app=$url" } else { Start-Process $url }
} catch {
  Write-Host ''; Write-Host ('ERRO: ' + $_.Exception.Message) -ForegroundColor Red
  exit 1
}
