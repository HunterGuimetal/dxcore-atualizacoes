﻿# DXCORE Finance - gerar um backup agora, na Área de Trabalho (para levar a outro computador)
# Não atualiza nem altera nada: só lê os dados e grava um arquivo .dxbak.
$pacote = Split-Path -Parent $PSScriptRoot
. (Join-Path $PSScriptRoot 'comum.ps1')
$Host.UI.RawUI.WindowTitle = 'DXCORE Finance - gerar backup'
if (-not (Test-Path $DXCfgArq)) { Write-Host 'O DXCORE Finance não está instalado neste computador.' -ForegroundColor Red; exit 1 }
# usa o programa de backup deste pacote (corrigido), não o instalado
$pasta = Join-Path $pacote 'sistema'; $node = Join-Path $pacote 'runtime\node.exe'
if (-not (Test-Path (Join-Path $pasta 'scripts\backup-dados.mjs'))) { $pasta = $DXSistema; $node = $DXNode }
try {
  $c = LerConfig
  Write-Host '-> Ligando o banco de dados'
  LigarBanco $c
  $u = UrlsAdmin $c
  $env:U = $u.Banco
  $js = "const p=require('postgres');(async()=>{const s=p(process.env.U,{max:1});const r=await s.unsafe('SELECT (SELECT count(*) FROM empresa) e,(SELECT count(*) FROM titulo) t,(SELECT count(*) FROM usuario) u');console.log(r[0].e+' empresa(s), '+r[0].t+' lancamento(s), '+r[0].u+' usuario(s)');await s.end()})().catch(e=>console.log('nao consegui contar: '+e.message))"
  Push-Location $pasta; Write-Host ('   Dados encontrados: ' + (& $node -e $js | Select-Object -Last 1)) -ForegroundColor Cyan; Pop-Location
  $mesa = [Environment]::GetFolderPath('Desktop')
  $arq = Join-Path $mesa ('DXCORE-Finance-backup-' + (Get-Date -Format 'yyyy-MM-dd_HHmm') + '.dxbak')
  Write-Host '-> Gravando o backup (cada tabela aparece abaixo)'
  $env:DATABASE_URL_ADMIN = $u.Banco; $env:DX_PROGRESSO = '1'
  Push-Location $pasta
  & $node (Join-Path $pasta 'scripts\backup-dados.mjs') $arq
  $cod = $LASTEXITCODE
  Pop-Location
  Remove-Item Env:DATABASE_URL_ADMIN, Env:DX_PROGRESSO -ErrorAction SilentlyContinue
  if ($cod -ne 0) { throw 'O backup não foi concluído (veja a mensagem acima).' }
  $kb = [math]::Round((Get-Item $arq).Length / 1KB, 1)
  Write-Host ''
  Write-Host "Backup pronto na Área de Trabalho: $(Split-Path -Leaf $arq) ($kb KB)" -ForegroundColor Green
  Write-Host 'Leve este arquivo ao outro computador e use o RESTAURAR-BACKUP.bat.'
} catch {
  Write-Host ''; Write-Host ('ERRO: ' + $_.Exception.Message) -ForegroundColor Red
  Log ('gerar-backup: ' + $_.Exception.Message)
  exit 1
}
