@echo off
title Instalar DXCORE v10.1
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0instalar.ps1"
if errorlevel 1 (
  echo.
  echo Nao foi possivel instalar. Extraia o zip antes de rodar o INSTALAR.bat.
)
echo.
pause
