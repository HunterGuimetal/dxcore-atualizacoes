﻿$ErrorActionPreference = 'Stop'
$origem = Split-Path -Parent $MyInvocation.MyCommand.Path
$dest = Join-Path $env:LOCALAPPDATA 'DXCORE'
New-Item -ItemType Directory -Force -Path $dest | Out-Null
foreach ($f in @('DXCORE.html', 'DXCORE.ico', 'abrir.ps1', 'abrir.vbs', 'atualizacao.json', 'versao.txt', 'voltar-versao-anterior.bat', 'servidor.ps1')) {
  Copy-Item (Join-Path $origem $f) $dest -Force
}
$vbs = Join-Path $dest 'abrir.vbs'
$wscript = Join-Path $env:WINDIR 'System32\wscript.exe'

# atalho: abre pelo lancador, que confere se tem versao nova antes de abrir o programa
$ws = New-Object -ComObject WScript.Shell
$lugares = @([Environment]::GetFolderPath('Desktop'), (Join-Path ([Environment]::GetFolderPath('StartMenu')) 'Programs'))
foreach ($p in $lugares) {
  $velho = Join-Path $p 'Limpa DXF.lnk'
  if (Test-Path $velho) { Remove-Item $velho -Force }
  $s = $ws.CreateShortcut((Join-Path $p 'DXCORE by GUIMETAL.lnk'))
  $s.TargetPath = $wscript
  $s.Arguments = "`"$vbs`""
  $s.IconLocation = (Join-Path $dest 'DXCORE.ico') + ',0'
  $s.Description = 'DXCORE by GUIMETAL'
  $s.WorkingDirectory = $dest
  $s.Save()
}
Write-Host ''
Write-Host 'DXCORE by GUIMETAL v8.42 instalado.'
Write-Host 'Atalho "DXCORE by GUIMETAL" na Area de Trabalho e no menu Iniciar.'
Write-Host 'A partir desta versao o DXCORE se atualiza sozinho ao abrir.'
Start-Process $wscript "`"$vbs`""
