@echo off
title Instalar DXCORE by GUIMETAL v9.18
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0instalar.ps1"
if errorlevel 1 (
  echo.
  echo Nao foi possivel instalar. Extraia o zip antes de rodar o INSTALAR.bat.
)
echo.
pause
